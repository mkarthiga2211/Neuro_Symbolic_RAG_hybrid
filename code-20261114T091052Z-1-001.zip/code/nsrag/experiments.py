"""Final runs: every model x every seed, ablations, decomposition, leakage check, relevance controls, Top-K.
Each (model, seed) is a unit that is marked done and skipped on rerun. Raw test forecasts are saved per unit."""
import os
import shutil

import numpy as np

from . import train as T
from . import tune as TU
from . import utils as U

# model -> where its hyperparameters come from
HP_SOURCE = {
    "proposed": "proposed", "proposed_sameday": "proposed", "rag_only": "proposed",
    "pen_only": "proposed", "sym_only": "proposed",
    "vanilla": "vanilla", "informer": "informer", "informer_c": "informer_c",
    "patchtst": "patchtst", "dlinear": "dlinear", "timellm": "timellm",
}
CONTROLS = ["shuffled", "shift365", "control_country", "zero"]


def best_hp(cfg, data, model):
    src = HP_SOURCE[model]
    if src in cfg.tune_models and cfg.tune_trials > 0:
        hp = dict(TU.tune(cfg, data, src))
    else:
        hp = {}
    if model in ("rag_only", "vanilla"):
        hp.pop("lam", None)
    return hp


def _pred_path(cfg, model, seed, variant):
    return cfg.path("preds", model, f"seed{seed}_{variant}.npy")


def run_model(cfg, data, model, seeds=None, K=None, tag=None, pretrained=True):
    """Train and evaluate one model for each seed. tag names the run folder (for Top-K runs)."""
    seeds = cfg.seeds if seeds is None else seeds
    hp = best_hp(cfg, data, model)
    if K is not None:
        hp["K"] = K
    name = tag or model
    spec = T.VARIANTS[model]
    variants = [spec["ctx"]]
    if model == "proposed" and tag is None:
        variants += CONTROLS
    for s in seeds:
        key = f"final:{name}:seed{s}"
        if U.is_done(key) and all(os.path.exists(_pred_path(cfg, name, s, v)) for v in variants):
            U.log(f"[skip] {name} seed {s}: trained and evaluated")
            continue
        run_dir = cfg.path("checkpoints", name, f"seed{s}")
        U.log(f"[run] {name} seed {s} (hp {hp})")
        summ = T.train(cfg, data, model, hp, s, run_dir, pretrained=pretrained)
        m = T.load_best(cfg, data, model, hp, run_dir, pretrained=pretrained)
        w = hp.get("w", cfg.window)
        for v in variants:
            p = _pred_path(cfg, name, s, v)
            if os.path.exists(p):
                continue
            raw = T.predict_raw(m, data, data.origins_test, w, v, hp.get("K", cfg.top_k), s)
            U.atomic_save_npy(p, raw.astype(np.float32))
        del m
        U.free_gpu()
        keep = cfg.keep_best_weights == "all" or (cfg.keep_best_weights == "seed0" and s == cfg.single_run_seed)
        if not keep and os.path.exists(os.path.join(run_dir, "best.pt")):
            os.remove(os.path.join(run_dir, "best.pt"))
        U.mark_done(key, {"best_epoch": summ["best_epoch"], "val_mape": summ["best_val_mape"],
                          "n_params": summ["n_params"]})
    return hp


def run_main(cfg, data, models=None):
    models = models or ["proposed", "vanilla", "informer", "informer_c", "patchtst", "dlinear", "timellm"]
    for m in models:
        run_model(cfg, data, m)


def run_ablations(cfg, data):
    # base = vanilla (already trained in run_main); (b) = vanilla + projection at inference (no retraining)
    for m in ["rag_only", "pen_only", "sym_only", "proposed_sameday"]:
        run_model(cfg, data, m)


def run_topk(cfg, data):
    for K in cfg.retrieval_ks:
        if K == cfg.top_k:
            continue
        run_model(cfg, data, "proposed", seeds=[cfg.single_run_seed], K=K, tag=f"proposed_K{K}")


def released(cfg, model, raw, C_mw):
    """Released forecast: projected for models that project at inference."""
    spec = T.VARIANTS.get(model.split("_K")[0] if model.startswith("proposed_K") else model)
    if spec is not None and spec["project"]:
        return np.clip(raw, 0.0, C_mw)
    return raw
