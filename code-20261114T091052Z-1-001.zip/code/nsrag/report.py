"""Collect all outputs into template-shaped CSVs (blocks A to J), summary statistics, forecast CSVs, and a
filled copy of Rerun_Results_Template.docx. Nothing here is typed by hand: every value is read from files
the pipeline wrote. Anything that was not run is written as "not run"."""
import json
import os
import shutil

import numpy as np
import pandas as pd

from . import metrics as MT
from . import utils as U
from .analysis import load_pred
from .experiments import released

NR = "not run"

MAIN_MODELS = [("Proposed NS-RAG", "proposed", "matched"), ("Vanilla LLM", "vanilla", "zero"),
               ("Informer", "informer", "zero"), ("Informer-C (penalty + projection)", "informer_c", "zero"),
               ("PatchTST", "patchtst", "zero"), ("DLinear", "dlinear", "zero"), ("Time-LLM", "timellm", "zero"),
               ("XGBoost + Text", "xgb_text", "matched")]


def _fmt(v, nd=2):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return NR
    if isinstance(v, (int, np.integer)):
        return f"{v:,}"
    if isinstance(v, (float, np.floating)):
        return f"{v:.{nd}f}"
    return str(v)


# ------------------------------------------------------------------ blocks
def block_b(cfg, data):
    y = data.y_mw(data.origins_test)
    rows = []
    for label, m, v in MAIN_MODELS:
        for s in cfg.seeds:
            p = load_pred(cfg, m, s, v)
            if p is None:
                continue
            r = MT.all_metrics(y, released(cfg, m, p, data.C_mw), data.C_mw)
            rows.append({"model": label, "key": m, "seed": s, **r})
    for label, m in [("ARIMA", "arima"), ("Prophet", "prophet")]:
        p = load_pred(cfg, m, 0, "matched")
        if p is not None:
            rows.append({"model": label, "key": m, "seed": "deterministic", **MT.all_metrics(y, p, data.C_mw)})
    df = pd.DataFrame(rows)
    U.atomic_to_csv(df, cfg.path("results", "raw", "blockB_main.csv"))
    return df


def block_c(cfg, data):
    y = data.y_mw(data.origins_test)
    spec = [("Base LLM (vanilla)", "vanilla", "zero"), ("Symbolic-only", "sym_only", "zero"),
            ("RAG-only", "rag_only", "matched"), ("Proposed (full)", "proposed", "matched")]
    rows = []
    for label, m, v in spec:
        row = {"variant": label}
        for s in cfg.seeds:
            p = load_pred(cfg, m, s, v)
            row[f"seed{s}"] = MT.mape(y, released(cfg, m, p, data.C_mw)) if p is not None else np.nan
        rows.append(row)
    df = pd.DataFrame(rows)
    U.atomic_to_csv(df, cfg.path("results", "raw", "blockC_ablation.csv"))
    return df


def block_d(cfg, data):
    """Fixed violating set from the raw forecasts of variant (a) of the same seed."""
    y = data.y_mw(data.origins_test)
    C = data.C_mw
    rows, counts = [], {}
    var = [("(a) No penalty, no projection", "vanilla", False), ("(b) Projection only", "vanilla", True),
           ("(c) Penalty only", "pen_only", False), ("(d) Penalty + projection (= symbolic-only)", "sym_only", True)]
    for s in cfg.seeds:
        pa = load_pred(cfg, "vanilla", s, "zero")
        if pa is None:
            continue
        vio = (pa > C).any(1)
        counts[s] = int(vio.sum())
        for label, m, proj in var:
            raw = load_pred(cfg, m, s, "zero")
            if raw is None:
                continue
            rel = np.clip(raw, 0, C) if proj else raw
            rows.append({"variant": label, "seed": s, "MAPE_all": MT.mape(y, rel),
                         "MAPE_nonviolating": MT.mape(y[~vio], rel[~vio]) if (~vio).any() else np.nan,
                         "MAPE_violating": MT.mape(y[vio], rel[vio]) if vio.any() else np.nan,
                         "raw_violation": MT.violation(raw, C), "released_violation": MT.violation(rel, C),
                         "n_violating_windows_a": int(vio.sum())})
    df = pd.DataFrame(rows)
    U.atomic_to_csv(df, cfg.path("results", "raw", "blockD_decomposition.csv"))
    return df, counts


def block_e(cfg, data):
    y = data.y_mw(data.origins_test)
    spec = [("Shuffled", "proposed", "shuffled"), ("Time-shifted by 365 days", "proposed", "shift365"),
            ("Non-matching country", "proposed", "control_country"), ("Event removal", "proposed", "zero"),
            ("Leakage check: same-day aggregation (retrained)", "proposed_sameday", "sameday"),
            ("Matched context (reference)", "proposed", "matched")]
    rows = []
    for label, m, v in spec:
        row = {"context": label}
        for s in cfg.seeds:
            p = load_pred(cfg, m, s, v)
            pr = np.clip(p, 0, data.C_mw) if p is not None else None
            row[f"seed{s}"] = MT.mape(y, pr) if p is not None else np.nan
            row[f"violation_seed{s}"] = MT.violation(pr, data.C_mw) if p is not None else np.nan
        rows.append(row)
    df = pd.DataFrame(rows)
    U.atomic_to_csv(df, cfg.path("results", "raw", "blockE_controls.csv"))
    return df


def block_h(cfg, data):
    from .tune import SPACE_TEXT
    rows = []
    for label, m in [("Proposed NS-RAG", "proposed"), ("Vanilla LLM", "vanilla"), ("Informer", "informer"),
                     ("Informer-C", "informer_c"), ("PatchTST", "patchtst"), ("DLinear", "dlinear"),
                     ("Time-LLM", "timellm"), ("XGBoost + Text", "xgb_text")]:
        best = U.read_json(cfg.path("tuning", f"{m}_best.json"), {})
        done = U.read_json(cfg.path("checkpoints", m, f"seed{cfg.single_run_seed}", "done.json"), {})
        if m == "xgb_text":
            params = f"{best.get('params', {}).get('n_estimators', '?')} trees (max)" if best else NR
        elif done:
            tr, tot = done.get("n_trainable", 0), done.get("n_params", 0)
            params = f"{tot / 1e6:.2f} M" + (f" ({tr / 1e6:.2f} M trainable)" if tr != tot else "")
        else:
            params = NR
        sel = ", ".join(f"{k} {v:.3g}" if isinstance(v, float) else f"{k} {v}"
                        for k, v in best.get("params", {}).items()) if best else NR
        trials = f"{best.get('n_complete', 0)} complete + {best.get('n_pruned', 0)} pruned" if best else NR
        rows.append({"model": label, "search_space": SPACE_TEXT.get(m, ""), "selected": sel, "parameters": params,
                     "trials": trials, "best_val_mape": best.get("value_val_mape", np.nan),
                     "epochs_run_seed0": done.get("epochs_run", NR)})
    ar = U.read_json(cfg.path("preds", "arima", "info.json"))
    rows.append({"model": "ARIMA / Prophet", "search_space": "SARIMA AIC grid p 1-2, d 1, q 0-2, seasonal "
                 "(1,0,1)24 or (0,1,1)24, exog T and |T-18|; Prophet daily + weekly + yearly + temperature",
                 "selected": f"ARIMA{tuple(ar['order'])}{tuple(ar['seasonal_order'][:3])}24" if ar else NR,
                 "parameters": str(ar["n_params"]) if ar else NR})
    df = pd.DataFrame(rows)
    U.atomic_to_csv(df, cfg.path("results", "raw", "blockH_configs.csv"))
    return df


def block_j(cfg, data):
    """Day-ahead MAE on the GEFCom2014 load-track evaluation months that fall in the test partition."""
    o = data.origins_test
    y = data.y_mw(o)
    p = load_pred(cfg, "proposed", cfg.single_run_seed, "matched")
    if p is None:
        return {"value": NR}
    p = np.clip(p, 0, data.C_mw)
    tt = data.ts[o + 1]
    m = (tt.year == 2011)
    if m.sum() == 0:
        return {"value": NR, "note": "no 2011 windows in the test partition"}
    months = sorted(set(tt[m].month))
    maes = [MT.mae(y[(tt.year == 2011) & (tt.month == mm)], p[(tt.year == 2011) & (tt.month == mm)])
            for mm in months]
    res = {"value": f"{np.mean(maes):.2f}", "months_covered": len(months),
           "note": (f"Day-ahead point forecasts, seed {cfg.single_run_seed}, mean of monthly MAE over {len(months)} "
                    "months of 2011 (check these are the scored task months). Pinball over 99 quantiles of a point "
                    "forecast = 0.5 x MAE. Competition forecasts were month-ahead, so this is not comparable.")}
    U.atomic_write_json(cfg.path("results", "raw", "blockJ_gefcom_months.json"), res)
    return res


def block_a(cfg, data, facts_load, facts_gdelt, facts_split):
    hw = U.hardware_summary()
    done = U.read_json(cfg.path("checkpoints", "proposed", f"seed{cfg.single_run_seed}", "done.json"), {})
    best = U.read_json(cfg.path("tuning", "proposed_best.json"), {}).get("params", {})
    tun = [U.read_json(cfg.path("tuning", f"{m}_best.json"), {}) for m in cfg.tune_models]
    n_trials = sorted({t.get("n_complete", 0) + t.get("n_pruned", 0) for t in tun if t})
    A = {
        "Load dataset and version used": "GEFCom2014 load track (GEFCom2014-L), mean of 25 station temperatures",
        "First and last timestamp of the load data used":
            f"{facts_load['first_timestamp'][:16]} to {facts_load['last_timestamp'][:16]} (hour-beginning)",
        "GDELT version and files used": f"GDELT 1.0 events; {facts_gdelt['files_used']}",
        "GDELT country filter": f"ActionGeo_CountryCode = {cfg.country}; control country {cfg.control_country}",
        "GDELT category / keyword filter": (f"CAMEO roots {', '.join(cfg.cameo_roots)} OR keyword match on actor names, "
                                            f"location and URL slug: {', '.join(cfg.keywords)}; "
                                            f"{facts_gdelt['share_keyword_matches'] * 100:.1f}% of kept records match a keyword"),
        "Text that is embedded for each record": facts_gdelt["text_embedded"],
        "Number of test windows": f"{facts_split['n_test_windows']:,} (origins every {cfg.origin_stride} h)",
        "Capacity ceiling C (MW)": f"{facts_split['capacity_C_mw']:.1f} (P{cfg.cap_percentile:.0f} = "
                                   f"{facts_split['train_p91_mw']:.1f} x {cfg.cap_factor})",
        "Mean hourly demand / trend level (MW)": f"{facts_load['mean_load_mw']:.1f}",
        "Language-model backbone": f"{cfg.lm_backbone}, fine-tuned end to end",
        "Backbone parameter count": (f"{done['n_params'] / 1e6:.1f} M (whole proposed model)" if done else NR),
        "Time-series encoder f_ts": f"linear patch embedding (patch {cfg.patch}, load + temperature) + "
                                    f"{cfg.ts_layers} transformer layers, hidden {cfg.ts_hidden}",
        "Fusion and head": "token sequence [CLS, patch tokens, future-temperature token, tone token, context "
                           "token] through DistilBERT; CLS output to a two-layer MLP with 24 outputs",
        "Input window w (hours)": str(best.get("w", cfg.window)),
        "Retrieval K / λ": f"K = {cfg.top_k}; λ = {best.get('lam', cfg.lam):.3g}",
        "Optimiser, learning rate, weight decay, batch size":
            f"AdamW, {best.get('lr', cfg.lr):.2g}, {cfg.weight_decay}, {cfg.batch_size}",
        "Max epochs / early-stopping patience": f"{cfg.max_epochs} / {cfg.patience} (tuning trials: "
                                                f"{cfg.tune_max_epochs} / {cfg.tune_patience}, median pruning)",
        "Optuna trials per model": (", ".join(map(str, n_trials)) + f" (TPE sampler, median pruner; trials "
                                    f"used every {cfg.tune_train_stride} training window(s))") if n_trials else NR,
        "Seeds used": ", ".join(map(str, cfg.seeds)),
        "Hardware": f"{hw.get('gpu', 'CPU')} ({hw.get('gpu_mem_gb', '?')} GB); {hw.get('cpu', '?')}; "
                    f"{hw.get('ram_gb', '?')} GB RAM (Google Colab)",
        "Software versions": f"Python {hw.get('python')}, PyTorch {hw.get('torch')}, transformers "
                             f"{hw.get('transformers')}, sentence-transformers {hw.get('sentence_transformers')}; "
                             "projection = closed-form clamp (no cvxpylayers)",
        "Code release tag and Zenodo DOI": "fill in after release",
        "MDF-LLM reference": "fill in from IEEE Xplore",
    }
    U.atomic_write_json(cfg.path("results", "raw", "blockA_settings.json"), A)
    return A


# ------------------------------------------------------------- summary stats
def summary(cfg, data, B, Cdf, D, E, F):
    out = []
    y = data.y_mw(data.origins_test)
    seeds = list(cfg.seeds)
    if not B.empty:
        neur = B[B["seed"] != "deterministic"]
        agg = neur.groupby("model", sort=False)[["MAPE", "MAE", "RMSE", "Violation"]].agg(["mean", "std"])
        agg.columns = [f"{a}_{b}" for a, b in agg.columns]
        U.atomic_to_csv(agg.reset_index(), cfg.path("results", "summary", "table3_mean_sd.csv"))
        prop = neur[neur.key == "proposed"].set_index("seed")
        rows = []
        # day-ahead origins (issued 23:00) give a non-overlapping hourly series for the DM test
        from .analysis import day_ahead_idx
        da = day_ahead_idx(data)
        pp_avg = np.mean([np.clip(load_pred(cfg, "proposed", s, "matched"), 0, data.C_mw) for s in seeds
                          if load_pred(cfg, "proposed", s, "matched") is not None], 0) if len(prop) else None
        for label, m, v in MAIN_MODELS[1:] + [("Symbolic-only variant", "sym_only", "zero"),
                                             ("RAG-only variant", "rag_only", "matched")]:
            other = neur[neur.key == m].set_index("seed") if m in set(neur.key) else None
            if m in ("sym_only", "rag_only"):
                vals = Cdf.set_index("variant").loc["Symbolic-only" if m == "sym_only" else "RAG-only"]
                b_mape = [vals[f"seed{s}"] for s in seeds]
                a_mape = [prop.loc[s, "MAPE"] for s in seeds if s in prop.index]
                b_mae = None
            elif other is not None and len(other) == len(prop) and len(prop) > 1:
                a_mape, b_mape = prop["MAPE"].values, other["MAPE"].reindex(prop.index).values
                b_mae = other["MAE"].reindex(prop.index).values
            else:
                continue
            if len(a_mape) != len(b_mape) or len(a_mape) < 2 or np.any(np.isnan(b_mape)):
                continue
            t1 = MT.paired_t(a_mape, b_mape)
            row = {"comparison": label, "dMAPE_mean": t1["mean_diff"], "dMAPE_ci": f"{t1['ci_low']:.2f} to {t1['ci_high']:.2f}",
                   "t_MAPE": t1["t"], "p_MAPE": t1["p"]}
            if b_mae is not None:
                t2 = MT.paired_t(prop["MAE"].values, b_mae)
                row.update({"dMAE_mean": t2["mean_diff"], "t_MAE": t2["t"], "p_MAE": t2["p"]})
            preds = [load_pred(cfg, m, s, v) for s in seeds]
            preds = [released(cfg, m, p, data.C_mw) for p in preds if p is not None]
            if pp_avg is not None and preds and len(da):
                ob = np.mean(preds, 0)
                dm = MT.diebold_mariano((pp_avg[da] - y[da]).ravel(), (ob[da] - y[da]).ravel(), lag=24)
                row.update({"DM": dm["DM"], "DM_p": dm["p"]})
            rows.append(row)
        U.atomic_to_csv(pd.DataFrame(rows), cfg.path("results", "summary", "tableS3_paired_tests.csv"))
    if not D.empty:
        agg = D.groupby("variant", sort=False).agg(["mean", "std"]).drop(columns=["seed"], level=0)
        agg.columns = [f"{a}_{b}" for a, b in agg.columns]
        U.atomic_to_csv(agg.reset_index(), cfg.path("results", "summary", "tableS2_decomposition.csv"))
    for df, name, key in [(Cdf, "ablation", "variant"), (E, "tableS4_controls", "context"),
                          (F, "table5_subgroups", "subgroup")]:
        if df is not None and not df.empty:
            cols = [f"seed{s}" for s in seeds]
            t = df[[key] + cols].copy()
            t["mean"] = t[cols].astype(float).mean(1)
            t["sd"] = t[cols].astype(float).std(1, ddof=1)
            U.atomic_to_csv(t, cfg.path("results", "summary", f"{name}_mean_sd.csv"))


def forecast_csvs(cfg, data):
    """One CSV per model: timestamp (target hour), y_true, y_pred (released), seed, origin, horizon."""
    o = data.origins_test
    y = data.y_mw(o)
    tgt = data.ts[(o[:, None] + np.arange(1, 25)).ravel()]
    org = np.repeat(data.ts[o], 24)
    hz = np.tile(np.arange(1, 25), len(o))
    for label, m, v in MAIN_MODELS + [("ARIMA", "arima", "matched"), ("Prophet", "prophet", "matched")]:
        path = cfg.path("forecasts", f"{m}_test_forecasts.csv.gz")
        seeds = [0] if m in ("arima", "prophet") else list(cfg.seeds)
        preds = {s: load_pred(cfg, m, s, v) for s in seeds}
        if any(p is None for p in preds.values()):
            continue
        key = f"forecast_csv:{m}"
        if U.is_done(key) and os.path.exists(path):
            continue
        parts = [pd.DataFrame({"timestamp": tgt, "y_true": y.ravel(),
                               "y_pred": released(cfg, m, p, data.C_mw).ravel(), "seed": s,
                               "origin": org, "horizon": hz}) for s, p in preds.items()]
        df = pd.concat(parts, ignore_index=True)
        tmp = path + ".tmp"
        df.to_csv(tmp, index=False, compression="gzip", float_format="%.3f")
        os.replace(tmp, path)
        U.mark_done(key)


# --------------------------------------------------------------- docx filling
def _set(cell, text):
    """Replace a cell's text and keep the formatting (yellow highlight) of its first run."""
    p = cell.paragraphs[0]
    if p.runs:
        p.runs[0].text = text
        for r in p.runs[1:]:
            r.text = ""
    else:
        from docx.enum.text import WD_COLOR_INDEX
        r = p.add_run(text)
        r.font.highlight_color = WD_COLOR_INDEX.YELLOW
    for extra in cell.paragraphs[1:]:
        for r in extra.runs:
            r.text = ""


def fill_template(cfg, A, B, Cdf, D, counts, E, F, G, H, I, J, template_path, out_path):
    import docx
    doc = docx.Document(template_path)
    tb = doc.tables
    seeds = list(cfg.seeds)
    seeds5 = (seeds + [None] * 5)[:5]          # template has five seed columns; unused ones get "not run"

    def sv(row, s):
        col = f"seed{s}"
        if s is None or not len(row) or col not in row.columns:
            return NR
        return _fmt(float(row[col].iloc[0]))

    for ti in (1, 2, 3, 4, 5):                 # seed headers follow the seeds actually used
        for k, s in enumerate(seeds5):
            if s is not None and tb[ti].rows[0].cells[2 + k].text.strip().startswith("Seed"):
                _set(tb[ti].rows[0].cells[2 + k], f"Seed {s}")

    def find_row(table, label, col=0, start=1):
        for i in range(start, len(table.rows)):
            if table.rows[i].cells[col].text.strip().lower().startswith(label.lower()[:25]):
                return i
        return None

    # A
    for i in range(1, len(tb[0].rows)):
        lab = tb[0].rows[i].cells[0].text.strip()
        for k, v in A.items():
            if lab.lower().startswith(k.lower()[:20]):
                _set(tb[0].rows[i].cells[1], str(v))
                break
    # B
    t = tb[1]
    order = ["MAPE", "MAE", "RMSE", "Violation"]
    for label, m, _ in MAIN_MODELS:
        r0 = find_row(t, label.split(" (")[0])
        if r0 is None:
            continue
        for j, met in enumerate(order):
            for k, s in enumerate(seeds5):
                v = B[(B.key == m) & (B.seed == s)][met]
                _set(t.rows[r0 + j].cells[2 + k], _fmt(float(v.iloc[0])) if len(v) else NR)
    r = find_row(t, "ARIMA")
    if r is not None:
        ar = B[B.key == "arima"]
        pr = B[B.key == "prophet"]
        for k, met in enumerate(order):
            txt = []
            if len(ar):
                txt.append(f"ARIMA {_fmt(float(ar[met].iloc[0]))}")
            if len(pr):
                txt.append(f"Prophet {_fmt(float(pr[met].iloc[0]))}")
            _set(t.rows[r].cells[2 + k], "; ".join(txt) if txt else NR)
    # C
    t = tb[2]
    for lab, key in [("Base LLM", "Base LLM (vanilla)"), ("Symbolic-only", "Symbolic-only"), ("RAG-only", "RAG-only")]:
        r = find_row(t, lab)
        row = Cdf[Cdf.variant == key]
        for k, s in enumerate(seeds5):
            _set(t.rows[r].cells[2 + k], sv(row, s))
    # D
    t = tb[3]
    mets = ["MAPE_all", "MAPE_nonviolating", "MAPE_violating", "raw_violation", "released_violation"]
    for lab in ["(a)", "(b)", "(c)", "(d)"]:
        r0 = find_row(t, lab)
        for j, met in enumerate(mets):
            for k, s in enumerate(seeds5):
                v = D[(D.variant.str.startswith(lab)) & (D.seed == s)][met] if not D.empty else []
                _set(t.rows[r0 + j].cells[2 + k], _fmt(float(v.iloc[0])) if len(v) and v.iloc[0] == v.iloc[0]
                 else ("no windows" if len(v) and met.startswith("MAPE_") else NR))
    r = find_row(t, "Number of violating")
    if r is not None:
        for k, s in enumerate(seeds5):
            _set(t.rows[r].cells[2 + k], _fmt(counts.get(s)) if s in counts else NR)
    # E
    t = tb[4]
    for lab, key in [("Shuffled", "Shuffled"), ("Time-shifted", "Time-shifted by 365 days"),
                     ("Non-matching", "Non-matching country"), ("Event removal", "Event removal"),
                     ("Leakage", "Leakage check: same-day aggregation (retrained)")]:
        r = find_row(t, lab)
        row = E[E.context == key]
        for k, s in enumerate(seeds5):
            _set(t.rows[r].cells[2 + k], sv(row, s))
        if lab == "Non-matching":
            c0 = t.rows[r].cells[0]
            c0.paragraphs[0].add_run(f"United Kingdom (FIPS {cfg.control_country})")
    # F
    t = tb[5]
    for i, (lab, key) in enumerate([("Heatwave", "Heatwave, Summer"), ("Grid", "Grid news, Winter"),
                                    ("Normal", "Normal, Transition"), ("High GDELT", "High GDELT Activity")]):
        r = find_row(t, lab)
        row = F[F.subgroup == key]
        if key.startswith("Grid"):
            _set(t.rows[r].cells[0], "Grid news, Winter (replaces Grid Maintenance; see definitions)")
        _set(t.rows[r].cells[1], _fmt(int(row["n_test_windows"].iloc[0])) if len(row) else NR)
        for k, s in enumerate(seeds5):
            _set(t.rows[r].cells[2 + k], sv(row, s))
    # G (keys are the template labels; the grid row holds the Grid news value)
    t = tb[6]
    norm = lambda x: " ".join(x.lower().split())
    Gn = {norm(k): v for k, v in G.items()}
    for i in range(1, len(t.rows)):
        lab = norm(t.rows[i].cells[0].text)
        hit = Gn.get(lab)
        if lab.startswith("figure 9 heatmap: grid"):
            _set(t.rows[i].cells[0], "Figure 9 heatmap: Grid news range (points) (replaces Grid Maintenance)")
        _set(t.rows[i].cells[1], _fmt(hit, 3) if hit is not None else NR)
    # H
    t = tb[7]
    for i in range(1, len(t.rows)):
        lab = t.rows[i].cells[0].text.strip()
        row = H[H.model.str.lower() == lab.lower()]
        if len(row):
            _set(t.rows[i].cells[1], str(row.search_space.iloc[0]))
            _set(t.rows[i].cells[2], str(row.selected.iloc[0]))
            _set(t.rows[i].cells[3], str(row.parameters.iloc[0]))
    # I
    t = tb[8]
    imap = {"proposed ns-rag (total)": "proposed", "retrieval only": "retrieval_only",
            "projection layer only": "projection_only", "vanilla llm": "vanilla", "informer": "informer",
            "patchtst": "patchtst", "dlinear": "dlinear", "arima": "arima"}
    for i in range(1, len(t.rows)):
        lab = t.rows[i].cells[0].text.strip().lower()
        if lab.startswith("timed runs"):
            _set(t.rows[i].cells[1], f"{cfg.latency_runs} (batch 1), {cfg.latency_runs_batch256} (batch 256) / "
                                     f"{cfg.latency_warmup}")
            continue
        key = next((v for k, v in imap.items() if lab.startswith(k)), None)
        row = I[I.model == key] if (I is not None and key) else []
        if len(row):
            b1, b256 = row["ms_per_window_b1"].iloc[0], row.get("ms_per_window_b256", pd.Series([np.nan])).iloc[0]
            _set(t.rows[i].cells[1], _fmt(float(b1), 3))
            _set(t.rows[i].cells[2], _fmt(float(b256), 4) if b256 == b256 else "not applicable")
            _set(t.rows[i].cells[3], str(row["hardware"].iloc[0]))
        else:
            for c in (1, 2, 3):
                _set(t.rows[i].cells[c], NR)
    # J
    _set(tb[9].rows[1].cells[1], str(J.get("value", NR)))
    if J.get("note"):
        _set(tb[9].rows[1].cells[2], J["note"])
    tmp = out_path + ".tmp.docx"
    doc.save(tmp)
    os.replace(tmp, out_path)


def build_all(cfg, data, facts_load, facts_gdelt, facts_split, G_extra=None):
    from . import analysis as AN
    B = block_b(cfg, data)
    Cdf = block_c(cfg, data)
    D, counts = block_d(cfg, data)
    E = block_e(cfg, data)
    F = AN.block_f(cfg, data)
    G = U.read_json(cfg.path("results", "raw", "blockG_single_run.json"), {})
    G.update(G_extra or U.read_json(cfg.path("results", "raw", "blockG_extra.json"), {}))
    H = block_h(cfg, data)
    ip = cfg.path("results", "raw", "blockI_latency.csv")
    I = pd.read_csv(ip) if os.path.exists(ip) else None
    J = block_j(cfg, data)
    A = block_a(cfg, data, facts_load, facts_gdelt, facts_split)
    summary(cfg, data, B, Cdf, D, E, F)
    try:
        AN.figure15(cfg, Cdf)
    except Exception as e:  # noqa: BLE001
        U.warn(f"Figure 15 skipped: {e}")
    forecast_csvs(cfg, data)
    tpl = cfg.path("Rerun_Results_Template.docx")
    out = cfg.path("results", "Rerun_Results_FILLED.docx")
    if os.path.exists(tpl):
        fill_template(cfg, A, B, Cdf, D, counts, E, F, G, H, I, J, tpl, out)
        U.log(f"Filled template written to {out}")
    else:
        U.warn(f"Template not found at {tpl}; upload Rerun_Results_Template.docx there to get a filled copy. "
               "All values are in results/raw and results/summary.")
    return {"A": A, "B": B, "C": Cdf, "D": D, "E": E, "F": F, "G": G, "H": H, "I": I, "J": J}
