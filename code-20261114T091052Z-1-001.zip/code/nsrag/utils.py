"""Resumability helpers: logging, progress.json, atomic writes, stage caching, seeding."""
import datetime as _dt
import json
import os
import random
import shutil
import sys
import time
from contextlib import contextmanager

import numpy as np

_LOG_FILE = None
_CFG = None


# ---------------------------------------------------------------- logging
def init(cfg):
    """Create the project folder tree on Drive and start the run log."""
    global _LOG_FILE, _CFG
    _CFG = cfg
    for sub in ["data/raw", "data/gdelt_filtered", "data/processed", "cache", "checkpoints",
                "tuning", "preds", "results/raw", "results/summary", "results/figures",
                "forecasts", "logs", "credentials"]:
        os.makedirs(cfg.path(sub), exist_ok=True)
    os.makedirs(cfg.local_tmp, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    _LOG_FILE = cfg.path("logs", f"run_{stamp}.log")
    log(f"Run started. Project folder: {cfg.project_dir}")
    atomic_write_text(cfg.path("logs", "config_last_run.json"), cfg.to_json())


def log(msg):
    line = f"[{_dt.datetime.now().strftime('%H:%M:%S')}] {msg}"
    print(line, flush=True)
    if _LOG_FILE:
        try:
            with open(_LOG_FILE, "a") as f:
                f.write(line + "\n")
        except OSError:
            pass


def warn(msg):
    log("WARNING: " + msg)


# ---------------------------------------------------------- atomic writes
def _tmp(path):
    return path + ".tmp"


def atomic_write_text(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(_tmp(path), "w") as f:
        f.write(text)
    os.replace(_tmp(path), path)


def atomic_write_json(path, obj):
    atomic_write_text(path, json.dumps(obj, indent=2, default=_json_default))


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    return str(o)


def read_json(path, default=None):
    if not os.path.exists(path):
        return default
    with open(path) as f:
        return json.load(f)


def atomic_save_npy(path, arr):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp.npy"
    np.save(tmp, arr)
    os.replace(tmp, path)


def atomic_to_csv(df, path, **kw):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = _tmp(path)
    df.to_csv(tmp, index=kw.pop("index", False), **kw)
    os.replace(tmp, path)


def atomic_to_parquet(df, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = _tmp(path)
    df.to_parquet(tmp, index=False)
    os.replace(tmp, path)


def atomic_torch_save(obj, path):
    import torch
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = _tmp(path)
    torch.save(obj, tmp)
    os.replace(tmp, path)


def atomic_savefig(fig, path, dpi=300):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path[:-4] + ".tmp" + path[-4:]
    fig.savefig(tmp, dpi=dpi, bbox_inches="tight")
    os.replace(tmp, path)


# -------------------------------------------------------------- progress
def _progress_path():
    return _CFG.path("progress.json")


def progress():
    return read_json(_progress_path(), {})


def mark_done(key, info=None):
    p = progress()
    p[key] = {"done_at": _dt.datetime.now().isoformat(timespec="seconds"), **(info or {})}
    atomic_write_json(_progress_path(), p)


def is_done(key):
    return key in progress()


def unmark(key):
    p = progress()
    if key in p:
        del p[key]
        atomic_write_json(_progress_path(), p)


def stage(key, outputs, fn, *args, **kwargs):
    """Run fn once. Skip it on rerun when progress.json records it and all outputs exist."""
    outs = [outputs] if isinstance(outputs, str) else list(outputs)
    if is_done(key) and all(os.path.exists(o) for o in outs):
        log(f"[skip] {key}: cached on Drive")
        return None
    if is_done(key):
        log(f"[redo] {key}: marked done but an output is missing, running again")
    else:
        log(f"[run] {key}")
    t0 = time.time()
    res = fn(*args, **kwargs)
    missing = [o for o in outs if not os.path.exists(o)]
    if missing:
        raise RuntimeError(f"Stage {key} finished without writing: {missing}")
    mark_done(key, {"seconds": round(time.time() - t0, 1)})
    log(f"[done] {key} in {time.time() - t0:.0f} s")
    return res


@contextmanager
def timer(name):
    t0 = time.time()
    yield
    log(f"{name}: {time.time() - t0:.1f} s")


# ---------------------------------------------------------------- runtime
def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
    except ImportError:
        pass


def rng_state():
    import torch
    st = {"python": random.getstate(), "numpy": np.random.get_state(),
          "torch": torch.get_rng_state()}
    if torch.cuda.is_available():
        st["cuda"] = torch.cuda.get_rng_state_all()
    return st


def set_rng_state(st):
    import torch
    random.setstate(st["python"])
    np.random.set_state(st["numpy"])
    torch.set_rng_state(st["torch"])
    if "cuda" in st and torch.cuda.is_available():
        torch.cuda.set_rng_state_all(st["cuda"])


def device():
    import torch
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def hardware_summary():
    import platform
    info = {"python": sys.version.split()[0], "platform": platform.platform()}
    try:
        import torch
        info["torch"] = torch.__version__
        info["gpu"] = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "none"
        if torch.cuda.is_available():
            info["gpu_mem_gb"] = round(torch.cuda.get_device_properties(0).total_memory / 1e9, 1)
    except ImportError:
        pass
    try:
        import psutil
        info["ram_gb"] = round(psutil.virtual_memory().total / 1e9, 1)
        info["cpu_count"] = psutil.cpu_count()
    except ImportError:
        info["cpu_count"] = os.cpu_count()
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith("model name"):
                    info["cpu"] = line.split(":", 1)[1].strip()
                    break
    except OSError:
        pass
    for pkg in ["transformers", "sentence_transformers", "optuna", "xgboost", "statsmodels", "prophet"]:
        try:
            mod = __import__(pkg)
            info[pkg] = getattr(mod, "__version__", "?")
        except Exception:
            pass
    return info


def resource_report(cfg):
    """Print free RAM, local disk and Drive space, and warn about likely limits."""
    import psutil
    vm = psutil.virtual_memory()
    local = shutil.disk_usage("/content" if os.path.exists("/content") else "/")
    try:
        drive = shutil.disk_usage(cfg.project_dir)
        drive_free = drive.free / 1e9
    except OSError:
        drive_free = float("nan")
    log(f"RAM free {vm.available / 1e9:.1f} of {vm.total / 1e9:.1f} GB; local disk free {local.free / 1e9:.0f} GB; "
        f"Drive free (as reported) {drive_free:.0f} GB")
    if vm.total < 20e9:
        warn("Standard Colab RAM (about 12.7 GB). Embedding and retrieval run in shards and chunks to fit; "
             "keep max_records_per_day at 300 or lower. If the session crashes with out-of-memory, lower it to 150.")
    if local.free < 30e9:
        warn("Less than 30 GB local disk. GDELT files are downloaded one at a time and deleted after filtering, "
             "so about 3 GB is needed at a time.")
    if drive_free == drive_free and drive_free < 15:
        warn(f"Only about {drive_free:.0f} GB free on Drive. Checkpoints of the DistilBERT models are about 0.8 GB each "
             "while a run is training (last 3 + best). Free space, lower keep_last_ckpts to 1, or use a bigger Drive plan.")
    try:
        import torch
        if not torch.cuda.is_available():
            warn("No GPU. Runtime > Change runtime type > T4 GPU. On CPU the language-model runs take days.")
    except ImportError:
        pass


def free_gpu():
    import gc
    gc.collect()
    try:
        import torch
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
    except ImportError:
        pass
