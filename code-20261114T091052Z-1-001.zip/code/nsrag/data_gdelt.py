"""GDELT 1.0 events: download, filter (country + CAMEO roots or keywords), build the text that is embedded,
and compute the daily tone and record count.

Files: yearly back-files up to 2005, monthly back-files 2006-01 to 2013-03, daily export files from 2013-04-01.
Each file is downloaded to local disk, filtered in chunks, saved as a small parquet on Drive, then deleted.
Each finished file is marked in progress.json, so a disconnect only repeats the file that was in progress.
"""
import datetime as dt
import io
import os
import re
import zipfile

import numpy as np
import pandas as pd

from . import utils as U

BASE56 = [
    "GLOBALEVENTID", "SQLDATE", "MonthYear", "Year", "FractionDate",
    "Actor1Code", "Actor1Name", "Actor1CountryCode", "Actor1KnownGroupCode", "Actor1EthnicCode",
    "Actor1Religion1Code", "Actor1Religion2Code", "Actor1Type1Code", "Actor1Type2Code", "Actor1Type3Code",
    "Actor2Code", "Actor2Name", "Actor2CountryCode", "Actor2KnownGroupCode", "Actor2EthnicCode",
    "Actor2Religion1Code", "Actor2Religion2Code", "Actor2Type1Code", "Actor2Type2Code", "Actor2Type3Code",
    "IsRootEvent", "EventCode", "EventBaseCode", "EventRootCode", "QuadClass", "GoldsteinScale",
    "NumMentions", "NumSources", "NumArticles", "AvgTone",
    "Actor1Geo_Type", "Actor1Geo_FullName", "Actor1Geo_CountryCode", "Actor1Geo_ADM1Code",
    "Actor1Geo_Lat", "Actor1Geo_Long", "Actor1Geo_FeatureID",
    "Actor2Geo_Type", "Actor2Geo_FullName", "Actor2Geo_CountryCode", "Actor2Geo_ADM1Code",
    "Actor2Geo_Lat", "Actor2Geo_Long", "Actor2Geo_FeatureID",
    "ActionGeo_Type", "ActionGeo_FullName", "ActionGeo_CountryCode", "ActionGeo_ADM1Code",
    "ActionGeo_Lat", "ActionGeo_Long", "ActionGeo_FeatureID",
]
EXTRA = ["DATEADDED", "SOURCEURL"]
KEEP = ["SQLDATE", "Actor1Name", "Actor2Name", "EventCode", "EventRootCode", "GoldsteinScale",
        "NumMentions", "AvgTone", "ActionGeo_FullName", "ActionGeo_CountryCode"]

CAMEO_ROOT = {
    "01": "Make public statement", "02": "Appeal", "03": "Express intent to cooperate", "04": "Consult",
    "05": "Engage in diplomatic cooperation", "06": "Engage in material cooperation", "07": "Provide aid",
    "08": "Yield", "09": "Investigate", "10": "Demand", "11": "Disapprove", "12": "Reject",
    "13": "Threaten", "14": "Protest", "15": "Exhibit force posture", "16": "Reduce relations",
    "17": "Coerce", "18": "Assault", "19": "Fight", "20": "Use unconventional mass violence",
}
CAMEO_URL = "https://www.gdeltproject.org/data/lookups/CAMEO.eventcodes.txt"


# ----------------------------------------------------------------- file list
def file_list(start, end):
    """GDELT 1.0 event files covering [start, end] (dates)."""
    names = [f"{y}.zip" for y in range(start.year, min(end.year, 2005) + 1)]
    m = dt.date(2006, 1, 1) if start.year < 2006 else dt.date(start.year, start.month, 1)
    while m <= end and m < dt.date(2013, 4, 1):
        names.append(f"{m.year}{m.month:02d}.zip")
        m = dt.date(m.year + (m.month == 12), m.month % 12 + 1, 1)
    d = max(start, dt.date(2013, 4, 1))
    while d <= end:
        names.append(f"{d:%Y%m%d}.export.CSV.zip")
        d += dt.timedelta(days=1)
    return names


def fetch(url, dest):
    """Download url to dest (overridable in tests)."""
    import requests
    with requests.get(url, stream=True, timeout=300) as r:
        if r.status_code == 404:
            raise FileNotFoundError(url)
        r.raise_for_status()
        tmp = dest + ".part"
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 22):
                f.write(chunk)
    os.replace(tmp, dest)


def _kw_regex(cfg):
    return re.compile("|".join(re.escape(k) for k in cfg.keywords), re.IGNORECASE)


def _filter_frame(cfg, df, kw_re, start_i, end_i):
    df = df[df["ActionGeo_CountryCode"].isin([cfg.country, cfg.control_country])]
    sq = pd.to_numeric(df["SQLDATE"], errors="coerce")
    df = df[(sq >= start_i) & (sq <= end_i)]
    if df.empty:
        return df
    root = df["EventRootCode"].astype(str).str.zfill(2)
    hay = (df["Actor1Name"].fillna("") + " " + df["Actor2Name"].fillna("") + " " +
           df["ActionGeo_FullName"].fillna(""))
    if "SOURCEURL" in df.columns:
        hay = hay + " " + df["SOURCEURL"].fillna("")
    kw = hay.str.contains(kw_re)
    keep = root.isin(cfg.cameo_roots) | kw
    out = df[keep].copy()
    out["EventRootCode"] = root[keep]
    out["kw_match"] = kw[keep].values
    return out


def filter_file(cfg, zpath, start, end):
    """Read one GDELT zip in chunks and keep the filtered records."""
    kw_re = _kw_regex(cfg)
    start_i, end_i = int(f"{start:%Y%m%d}"), int(f"{end:%Y%m%d}")
    parts = []
    with zipfile.ZipFile(zpath) as z:
        inner = [n for n in z.namelist() if n.lower().endswith((".csv", ".txt"))]
        for name in inner:
            with z.open(name) as fh:
                first = fh.readline().decode("utf-8", "replace")
            ncol = len(first.rstrip("\n").split("\t"))
            if ncol < 56:
                raise ValueError(f"{name}: {ncol} columns, expected 56 to 58")
            names = BASE56 + EXTRA[: ncol - 56]
            usecols = KEEP + (["SOURCEURL"] if "SOURCEURL" in names else [])
            with z.open(name) as fh:
                reader = pd.read_csv(io.TextIOWrapper(fh, encoding="utf-8", errors="replace"), sep="\t",
                                     header=None, names=names, usecols=usecols, dtype=str,
                                     quoting=3, chunksize=500_000, on_bad_lines="skip")
                for chunk in reader:
                    f = _filter_frame(cfg, chunk, kw_re, start_i, end_i)
                    if len(f):
                        parts.append(f)
    if not parts:
        return pd.DataFrame(columns=KEEP + ["SOURCEURL", "kw_match"])
    out = pd.concat(parts, ignore_index=True)
    if "SOURCEURL" not in out.columns:
        out["SOURCEURL"] = None
    # validation that columns were mapped correctly
    sq = pd.to_datetime(out["SQLDATE"], format="%Y%m%d", errors="coerce")
    if sq.isna().mean() > 0.01:
        raise ValueError(f"{zpath}: SQLDATE column does not parse; the column layout is not as expected")
    return out


def download_and_filter(cfg, start, end):
    """Loop over all GDELT files; each finished file is skipped on rerun."""
    if cfg.gdelt_source == "bigquery":
        return _bigquery(cfg, start, end)
    names = file_list(start, end)
    U.log(f"GDELT: {len(names)} files for {start} to {end}")
    out_dir = cfg.path("data", "gdelt_filtered")
    missing = []
    for i, name in enumerate(names):
        key = f"gdelt_file:{name}"
        out = os.path.join(out_dir, name.replace(".zip", ".parquet"))
        if U.is_done(key) and os.path.exists(out):
            continue
        zpath = os.path.join(cfg.local_tmp, name)
        try:
            if not os.path.exists(zpath):
                fetch(cfg.gdelt_base_url + name, zpath)
            df = filter_file(cfg, zpath, start, end)
            U.atomic_to_parquet(df, out)
            U.mark_done(key, {"rows": int(len(df))})
            U.log(f"[done] GDELT {name} ({i + 1}/{len(names)}): {len(df)} records kept")
        except FileNotFoundError:
            missing.append(name)
            U.mark_done(key, {"rows": 0, "missing_on_server": True})
            U.atomic_to_parquet(pd.DataFrame(columns=KEEP + ["SOURCEURL", "kw_match"]), out)
            U.warn(f"GDELT file not on server: {name} (recorded as missing)")
        finally:
            if os.path.exists(zpath):
                os.remove(zpath)
    done_rows = sum(U.progress().get(f"gdelt_file:{n}", {}).get("rows", 0) for n in names)
    U.log(f"[skip/done] GDELT download: {len(names)} files, {done_rows} filtered records, {len(missing)} missing")
    return names, missing


def _bigquery(cfg, start, end):
    """Same filter run on BigQuery (gdelt-bq.full.events). Needs a Google Cloud project."""
    from google.cloud import bigquery
    client = bigquery.Client(project=cfg.gcp_project)
    out_dir = cfg.path("data", "gdelt_filtered")
    names = []
    kw = "|".join(re.escape(k) for k in cfg.keywords)
    roots = ",".join(f"'{r}'" for r in cfg.cameo_roots)
    for year in range(start.year, end.year + 1):
        name = f"bq_{year}.zip"
        names.append(name)
        key = f"gdelt_file:{name}"
        out = os.path.join(out_dir, name.replace(".zip", ".parquet"))
        if U.is_done(key) and os.path.exists(out):
            continue
        a = max(start, dt.date(year, 1, 1))
        b = min(end, dt.date(year, 12, 31))
        q = f"""
        SELECT CAST(SQLDATE AS STRING) SQLDATE, Actor1Name, Actor2Name, EventCode, EventRootCode,
               CAST(GoldsteinScale AS STRING) GoldsteinScale, CAST(NumMentions AS STRING) NumMentions,
               CAST(AvgTone AS STRING) AvgTone, ActionGeo_FullName, ActionGeo_CountryCode, SOURCEURL,
               REGEXP_CONTAINS(LOWER(CONCAT(IFNULL(Actor1Name,''),' ',IFNULL(Actor2Name,''),' ',
                   IFNULL(ActionGeo_FullName,''),' ',IFNULL(SOURCEURL,''))), r'{kw.lower()}') AS kw_match
        FROM `gdelt-bq.full.events`
        WHERE SQLDATE BETWEEN {a:%Y%m%d} AND {b:%Y%m%d}
          AND ActionGeo_CountryCode IN ('{cfg.country}', '{cfg.control_country}')
          AND (LPAD(CAST(EventRootCode AS STRING), 2, '0') IN ({roots})
               OR REGEXP_CONTAINS(LOWER(CONCAT(IFNULL(Actor1Name,''),' ',IFNULL(Actor2Name,''),' ',
                   IFNULL(ActionGeo_FullName,''),' ',IFNULL(SOURCEURL,''))), r'{kw.lower()}'))
        """
        U.log(f"BigQuery GDELT {year}")
        df = client.query(q).to_dataframe()
        df["EventRootCode"] = df["EventRootCode"].astype(str).str.zfill(2)
        U.atomic_to_parquet(df, out)
        U.mark_done(key, {"rows": int(len(df))})
    return names, []


# ------------------------------------------------------------------- text
def _cameo_lookup(cfg):
    path = cfg.path("data", "raw", "CAMEO.eventcodes.txt")
    if not os.path.exists(path):
        try:
            fetch(CAMEO_URL, path)
        except Exception as e:  # noqa: BLE001
            U.warn(f"Could not download CAMEO code descriptions ({e}); using root descriptions only")
            return {}
    lk = pd.read_csv(path, sep="\t", dtype=str)
    return dict(zip(lk.iloc[:, 0].str.strip(), lk.iloc[:, 1].str.strip()))


def _url_slug(u):
    if not isinstance(u, str) or not u:
        return ""
    s = u.split("?")[0].rstrip("/").split("/")[-1]
    s = re.sub(r"\.(html?|php|aspx?|cms|shtml)$", "", s, flags=re.I)
    s = re.sub(r"[-_+]+", " ", s)
    s = re.sub(r"\b\d{5,}\b", " ", s)
    return re.sub(r"\s+", " ", s).strip().lower()


def build_records(cfg, names):
    """Concatenate filtered files, build the embedded text, deduplicate within a day."""
    out_rec = cfg.path("data", "processed", "gdelt_records.parquet")
    out_daily = cfg.path("data", "processed", "gdelt_daily.parquet")
    out_facts = cfg.path("data", "processed", "gdelt_facts.json")

    def _run():
        frames = []
        for n in names:
            p = cfg.path("data", "gdelt_filtered", n.replace(".zip", ".parquet"))
            if os.path.exists(p):
                d = pd.read_parquet(p)
                if len(d):
                    frames.append(d)
        if not frames:
            raise RuntimeError("No GDELT records after filtering. Check the download stage log.")
        df = pd.concat(frames, ignore_index=True)
        del frames
        df["date"] = pd.to_datetime(df["SQLDATE"], format="%Y%m%d", errors="coerce")
        df = df[df["date"].notna()]
        df["tone"] = pd.to_numeric(df["AvgTone"], errors="coerce")
        df["mentions"] = pd.to_numeric(df["NumMentions"], errors="coerce").fillna(1)
        cameo = _cameo_lookup(cfg)
        code = df["EventCode"].astype(str).str.strip()
        desc = code.map(cameo)
        desc = desc.fillna(df["EventRootCode"].map(CAMEO_ROOT)).fillna("Event")
        a1 = df["Actor1Name"].fillna("").str.title()
        a2 = df["Actor2Name"].fillna("").str.title()
        geo = df["ActionGeo_FullName"].fillna("")
        slug = df["SOURCEURL"].map(_url_slug) if "SOURCEURL" in df.columns else ""
        actors = np.where((a1 != "") & (a2 != ""), a1 + " and " + a2, a1 + a2)
        text = desc + ": " + pd.Series(actors, index=df.index).replace("", "unnamed actors") + " in " + geo
        text = text.where(pd.Series(slug, index=df.index).fillna("") == "",
                          text + ". " + pd.Series(slug, index=df.index).fillna(""))
        df["text"] = text.str.replace(r"\s+", " ", regex=True).str.strip()
        df["norm"] = df["text"].str.lower().str.replace(r"[^a-z0-9 ]", "", regex=True)
        df["country"] = df["ActionGeo_CountryCode"]
        grid_re = re.compile("|".join(re.escape(k) for k in cfg.grid_keywords), re.I)
        df["grid_kw"] = df["text"].str.contains(grid_re)
        # daily aggregates on all filtered records (Eq. 4)
        daily = (df.groupby(["country", "date"])
                   .agg(n_records=("tone", "size"), mean_tone=("tone", "mean"),
                        n_grid_kw=("grid_kw", "sum"), n_kw=("kw_match", "sum"))
                   .reset_index())
        # retrieval corpus: dedup within day, then cap per day by coverage
        n_before = len(df)
        df = df.sort_values(["country", "date", "mentions"], ascending=[True, True, False])
        df = df.drop_duplicates(["country", "date", "norm"])
        n_dedup = len(df)
        if cfg.max_records_per_day:
            df = df.groupby(["country", "date"], sort=False).head(cfg.max_records_per_day)
        rec = df[["country", "date", "text", "tone", "mentions", "EventRootCode", "kw_match", "grid_kw"]]
        U.atomic_to_parquet(rec.reset_index(drop=True), out_rec)
        U.atomic_to_parquet(daily, out_daily)
        has_url = bool(df.get("SOURCEURL", pd.Series(dtype=str)).notna().any())
        facts = {
            "files_used": f"{sum(1 for n in names if n[:4].isdigit() and len(n) == 8)} yearly, "
                          f"{sum(1 for n in names if len(n) == 10)} monthly back-files, "
                          f"{sum(1 for n in names if 'export' in n)} daily export files",
            "n_filtered_records": int(n_before),
            "n_after_within_day_dedup": int(n_dedup),
            "n_retrieval_corpus_records": int(len(rec)),
            "max_records_per_day": cfg.max_records_per_day,
            "records_by_country": rec["country"].value_counts().to_dict(),
            "share_keyword_matches": float(df["kw_match"].mean()),
            "text_embedded": ("'<CAMEO event description>: <Actor1Name> and <Actor2Name> in <ActionGeo_FullName>'"
                              + (" plus the source URL slug when available (daily files from April 2013)"
                                 if has_url else "; back-files have no source URL")),
            "first_date": str(rec["date"].min().date()),
            "last_date": str(rec["date"].max().date()),
        }
        U.atomic_write_json(out_facts, facts)
        U.log(f"GDELT records: {n_before} filtered, {len(rec)} in the retrieval corpus")

    U.stage("gdelt_records", [out_rec, out_daily, out_facts], _run)
    return out_rec, out_daily, U.read_json(out_facts)
