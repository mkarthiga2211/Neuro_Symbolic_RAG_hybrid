"""Hybrid NS-RAG: equal-weight blend of the NS-RAG language-model branch and the XGBoost + text branch,
followed by the same projection onto [0, C] (Eq. 14).

    y_hybrid = clip(0.5 * clip(y_llm, 0, C) + 0.5 * y_xgb, 0, C)

The weight 0.5 is fixed in advance (no tuning on validation or test). Everything is computed from the
forecasts the main run already saved, so no model is retrained. Outputs go to results/hybrid/ and never
overwrite the main results:
    results/hybrid/hybrid.json            metrics, tests, clamp statistics, subgroups, figure facts, latency
    results/hybrid/raw/*.csv              per-seed metrics, paired tests, subgroups, Figure 9 cells
    results/hybrid/figures/*.png          Figures 6 to 9, 13 to 16 with the hybrid as "Proposed NS-RAG"
    forecasts/hybrid_test_forecasts.csv.gz
"""
import json
import os
import time

import numpy as np
import pandas as pd

from . import analysis as AN
from . import metrics as MT
from . import utils as U
from .experiments import released
from .report import MAIN_MODELS

W_LLM = 0.5


class _HybridCfg:
    """Config view that writes results/... into results/hybrid/... and reads everything else unchanged."""

    def __init__(self, cfg):
        self._cfg = cfg

    def __getattr__(self, k):
        return getattr(self._cfg, k)

    def path(self, *parts):
        if parts and parts[0] == "results":
            parts = ("results", "hybrid") + tuple(parts[1:])
        p = self._cfg.path(*parts)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        return p


def hybrid_pred(cfg, data, seed):
    pl = AN.load_pred(cfg, "proposed", seed, "matched")
    px = AN.load_pred(cfg, "xgb_text", seed, "matched")
    if pl is None or px is None:
        return None
    return np.clip(W_LLM * np.clip(pl, 0, data.C_mw) + (1 - W_LLM) * px, 0, data.C_mw).astype(np.float32)


def _released_pred(cfg, data, m, s, v):
    p = AN.load_pred(cfg, m, s, v)
    return None if p is None else released(cfg, m, p, data.C_mw)


def run(S):
    cfg, data = S.cfg, S.data
    H = _HybridCfg(cfg)
    seeds = list(cfg.seeds)
    o = data.origins_test
    y = data.y_mw(o)
    C = data.C_mw
    res = {"definition": f"clip({W_LLM} x NS-RAG LLM branch (released) + {1 - W_LLM} x XGBoost+Text, 0, C)",
           "weight_llm": W_LLM, "weight_source": "fixed a priori, not tuned", "C_mw": C}

    # ---- hybrid forecasts and per-seed metrics
    hp = {s: hybrid_pred(cfg, data, s) for s in seeds}
    missing = [s for s, p in hp.items() if p is None]
    if missing:
        raise RuntimeError(f"hybrid: proposed or XGBoost forecasts missing for seeds {missing}")
    for s, p in hp.items():
        U.atomic_save_npy(cfg.path("preds", "hybrid", f"seed{s}_matched.npy"), p)
    rows = []
    comps = MAIN_MODELS + [("XGBoost-C (projection at inference)", "xgb_c", "matched"),
                           ("Proposed NS-RAG (hybrid)", "hybrid", "matched")]

    def pred_of(m, s, v):
        if m == "hybrid":
            return hp[s]
        if m == "xgb_c":
            p = AN.load_pred(cfg, "xgb_text", s, "matched")
            return None if p is None else np.clip(p, 0, C)
        return _released_pred(cfg, data, m, s, v)

    for label, m, v in comps:
        for s in seeds:
            p = pred_of(m, s, v)
            if p is not None:
                rows.append({"model": label, "key": m, "seed": s, **MT.all_metrics(y, p, C)})
    for label, m in [("ARIMA", "arima"), ("Prophet", "prophet")]:
        p = AN.load_pred(cfg, m, 0, "matched")
        if p is not None:
            rows.append({"model": label, "key": m, "seed": "deterministic", **MT.all_metrics(y, p, C)})
    B = pd.DataFrame(rows)
    U.atomic_to_csv(B, H.path("results", "raw", "table3_with_hybrid_per_seed.csv"))
    neur = B[B.seed != "deterministic"]
    agg = neur.groupby("model", sort=False)[["MAPE", "MAE", "RMSE", "Violation"]].agg(["mean", "std"])
    agg.columns = [f"{a}_{b}" for a, b in agg.columns]
    agg = pd.concat([agg.reset_index(), B[B.seed == "deterministic"].drop(columns=["key", "seed"])],
                    ignore_index=True)
    U.atomic_to_csv(agg, H.path("results", "summary", "table3_with_hybrid_mean_sd.csv"))
    hb = neur[neur.key == "hybrid"].set_index("seed")
    res["per_seed"] = hb[["MAPE", "MAE", "RMSE", "Violation"]].reset_index().to_dict("records")
    res["mean_sd"] = {k: [float(hb[k].mean()), float(hb[k].std(ddof=1))] for k in ["MAPE", "MAE", "RMSE", "Violation"]}

    # ---- clamp statistics: how much the final projection changes the blend
    hc, mc = [], []
    for s in seeds:
        pl = np.clip(AN.load_pred(cfg, "proposed", s, "matched"), 0, C)
        blend = W_LLM * pl + (1 - W_LLM) * AN.load_pred(cfg, "xgb_text", s, "matched")
        over = blend > C
        hc.append(int(over.sum()))
        mc.append(float((blend - C)[over].mean()) if over.any() else 0.0)
    res["clamp"] = {"hours_clamped_per_seed": hc, "mean_correction_mw_per_seed": mc}
    uniq = pd.Series(y.ravel(), index=data.ts[(o[:, None] + np.arange(1, 25)).ravel()])
    uniq = uniq[~uniq.index.duplicated()]
    res["actual_load_above_C"] = {"hours": int((uniq > C).sum()), "of_test_hours": int(len(uniq))}

    # ---- paired tests (seed level) and DM (day-ahead windows, seed-averaged forecasts) vs every model
    da = AN.day_ahead_idx(data)
    h_avg = np.mean([hp[s] for s in seeds], 0)
    tests = []
    for label, m, v in comps:
        if m == "hybrid":
            continue
        other = neur[neur.key == m].set_index("seed")
        row = {"comparison": label}
        if len(other) == len(hb) and len(hb) > 1:
            t1 = MT.paired_t(hb["MAPE"].values, other["MAPE"].reindex(hb.index).values)
            t2 = MT.paired_t(hb["MAE"].values, other["MAE"].reindex(hb.index).values)
            row.update({"dMAPE_mean (other - hybrid)": t1["mean_diff"], "dMAPE_ci_low": t1["ci_low"],
                        "dMAPE_ci_high": t1["ci_high"], "t_MAPE": t1["t"], "p_MAPE": t1["p"],
                        "dMAE_mean": t2["mean_diff"], "t_MAE": t2["t"], "p_MAE": t2["p"]})
        preds = [pred_of(m, s, v) for s in seeds]
        preds = [p for p in preds if p is not None]
        if preds and len(da):
            dm = MT.diebold_mariano((h_avg[da] - y[da]).ravel(), (np.mean(preds, 0)[da] - y[da]).ravel(), lag=24)
            row.update({"DM": dm["DM"], "DM_p": dm["p"], "DM_n_hours": dm["n"]})
        tests.append(row)
    for label, m in [("ARIMA", "arima"), ("Prophet", "prophet")]:
        p = AN.load_pred(cfg, m, 0, "matched")
        if p is not None and len(da):
            dm = MT.diebold_mariano((h_avg[da] - y[da]).ravel(), (p[da] - y[da]).ravel(), lag=24)
            tests.append({"comparison": label, "DM": dm["DM"], "DM_p": dm["p"], "DM_n_hours": dm["n"],
                          "note": "deterministic: DM only, no seed-level t-test"})
    T = pd.DataFrame(tests)
    U.atomic_to_csv(T, H.path("results", "summary", "paired_tests_vs_hybrid.csv"))
    res["tests"] = T.to_dict("records")
    res["tests_note"] = ("dMAPE = MAPE(other) - MAPE(hybrid), so positive means the hybrid is better. DM statistic "
                         "positive means the hybrid has lower absolute error (day-ahead windows issued at 23:00, "
                         "Newey-West lag 24).")

    # ---- subgroups (Table 5) and figures, with the hybrid as "proposed"
    orig = AN.load_pred

    def patched(c, model, seed, variant="matched"):
        if model == "proposed" and variant == "matched":
            return hp.get(seed)
        return orig(c, model, seed, variant)

    AN.load_pred = patched
    try:
        F = AN.block_f(H, data)
        G = AN.block_g(H, data, S.emb, S.rec_tid)
    finally:
        AN.load_pred = orig
    sub_rows = []
    L, _ = AN.window_labels(cfg, data)
    for name, f in AN.SUBGROUPS.items():
        m = f(L).values
        r = {"subgroup": name, "n_test_windows": int(m.sum())}
        for s in seeds:
            r[f"hybrid_MAPE_seed{s}"] = MT.mape(y[m], hp[s][m]) if m.sum() else np.nan
        sub_rows.append(r)
    SG = pd.DataFrame(sub_rows)
    U.atomic_to_csv(SG, H.path("results", "raw", "table5_hybrid_subgroup_mape.csv"))
    imp = F.set_index("subgroup")[[f"seed{s}" for s in seeds]].astype(float)
    res["table5_improvement_vs_vanilla"] = {k: {"n": int(F.set_index("subgroup").loc[k, "n_test_windows"]),
                                                "mean": float(v.mean()), "sd": float(v.std(ddof=1)),
                                                "per_seed": [float(x) for x in v.values]}
                                            for k, v in imp.iterrows()}
    res["table5_hybrid_mape"] = {r["subgroup"]: [float(r[f"hybrid_MAPE_seed{s}"]) for s in seeds] for r in sub_rows}
    keep = [k for k in G if k.startswith(("Figure 9", "Peak week", "Confusion", "Extreme", "Vanilla LLM",
                                          "Projection"))]
    res["figure_facts"] = {k: G[k] for k in keep}
    dd = AN.day_ahead_idx(data)
    if len(dd) >= 7:
        wk = int(np.argmax(np.convolve(y[dd].mean(1), np.ones(7), "valid")))
        sel = dd[wk:wk + 7]
        s0 = cfg.single_run_seed
        under = y[sel].max(1) - hp[s0][sel].max(1)
        res["figure_facts"]["Peak week (Figure 8): hybrid under-prediction range at daily peaks (MW)"] = (
            f"{under.min():.1f} to {under.max():.1f}")
        res["figure_facts"]["Peak week (Figure 8): MAPE that week, vanilla / hybrid (%)"] = (
            f"{MT.mape(y[sel], AN.load_pred(cfg, 'vanilla', s0, 'zero')[sel]):.2f} / {MT.mape(y[sel], hp[s0][sel]):.2f}")
    res["figure_facts_note"] = ("Figures 2 to 5, 10, 11 and 12 and Table 2 (Top-K) are unchanged from the main "
                                "run: they describe the data or the LLM branch.")

    # ---- Figure 15: ablation including both branches
    plt = AN._plt()
    abl = pd.read_csv(cfg.path("results", "summary", "ablation_mean_sd.csv")).set_index("variant")
    bars = [("Base LLM\n(vanilla)", abl.loc["Base LLM (vanilla)", [f"seed{s}" for s in seeds]].values),
            ("Symbolic-only", abl.loc["Symbolic-only", [f"seed{s}" for s in seeds]].values),
            ("RAG-only", abl.loc["RAG-only", [f"seed{s}" for s in seeds]].values),
            ("LLM branch\n(RAG + symbolic)", abl.loc["Proposed (full)", [f"seed{s}" for s in seeds]].values),
            ("XGBoost-C\n(branch 2)", neur[neur.key == "xgb_c"].sort_values("seed").MAPE.values),
            ("Proposed NS-RAG\n(hybrid)", hb.sort_index().MAPE.values)]
    fig, ax = plt.subplots(figsize=(11, 4.8))
    ax.bar([b[0] for b in bars], [np.mean(b[1]) for b in bars], yerr=[np.std(b[1], ddof=1) for b in bars],
           capsize=6, color=["#999999", "#6baed6", "#74c476", "#41ab5d", "#fd8d3c", "#238b45"])
    for i, b in enumerate(bars):
        ax.text(i, np.mean(b[1]) + np.std(b[1], ddof=1) + 0.15, f"{np.mean(b[1]):.2f}", ha="center", va="bottom")
    ax.set(ylabel="MAPE (%)", title="Ablation: five-seed mean test MAPE (± SD)")
    ax.set_ylim(0, max(np.mean(b[1]) for b in bars) * 1.15)
    AN._save(H, fig, "fig15_ablation.png")
    res["figure15_bars"] = {b[0].replace("\n", " "): [float(np.mean(b[1])), float(np.std(b[1], ddof=1))] for b in bars}

    # ---- latency: LLM branch (main run, GPU) + XGBoost branch on this machine
    res["latency"] = _latency(cfg, data)

    # ---- forecast CSV
    tgt = data.ts[(o[:, None] + np.arange(1, 25)).ravel()]
    org = np.repeat(data.ts[o], 24)
    hz = np.tile(np.arange(1, 25), len(o))
    df = pd.concat([pd.DataFrame({"timestamp": tgt, "y_true": y.ravel(), "y_pred": hp[s].ravel(), "seed": s,
                                  "origin": org, "horizon": hz}) for s in seeds], ignore_index=True)
    path = cfg.path("forecasts", "hybrid_test_forecasts.csv.gz")
    df.to_csv(path + ".tmp", index=False, compression="gzip", float_format="%.3f")
    os.replace(path + ".tmp", path)

    U.atomic_write_json(H.path("results", "hybrid.json"), res)
    U.mark_done("hybrid")
    U.log("[done] hybrid: results in results/hybrid/, forecasts/hybrid_test_forecasts.csv.gz")
    return res


def _latency(cfg, data):
    import torch
    lat = cfg.path("results", "raw", "blockI_latency.csv")
    out = {}
    if os.path.exists(lat):
        L = pd.read_csv(lat).set_index("model")
        for k in ["proposed", "retrieval_only", "projection_only"]:
            if k in L.index:
                out[f"{k}_ms_b1"] = float(L.loc[k, "ms_per_window_b1"])
                out[f"{k}_ms_b256"] = float(L.loc[k, "ms_per_window_b256"])
        out["llm_branch_hardware"] = str(L.loc["proposed", "hardware"]) if "proposed" in L.index else None
    mp = cfg.path("preds", "xgb_text", f"seed{cfg.single_run_seed}_model.json")
    feats = cfg.path("cache", "xgb_features.npz")
    if not (os.path.exists(mp) and os.path.exists(feats)):
        out["xgb"] = "XGBoost model or features not found; XGBoost latency not measured"
        return out
    import xgboost as xgb
    from .baselines_classic import xgb_features
    m = xgb.XGBRegressor()
    m.load_model(mp)
    m.set_params(device="cpu", n_jobs=1)
    z = np.load(feats)
    P = z["P"]
    o = data.origins_test

    def timeit(fn, runs, warm):
        for _ in range(warm):
            fn()
        ts = []
        for _ in range(runs):
            t0 = time.perf_counter()
            fn()
            ts.append((time.perf_counter() - t0) * 1000)
        q = np.percentile(ts, [25, 50, 75])
        return float(q[1]), float((q[2] - q[0]) / 2)

    for bs, runs in [(1, cfg.latency_runs), (256, cfg.latency_runs_batch256)]:
        oo = o[:bs]
        f_med, f_iqr = timeit(lambda: xgb_features(data, oo, P), runs, cfg.latency_warmup)
        X = xgb_features(data, oo, P)
        p_med, p_iqr = timeit(lambda: m.predict(X), runs, cfg.latency_warmup)
        out[f"xgb_features_ms_per_window_b{bs}"] = f_med / bs
        out[f"xgb_predict_ms_per_window_b{bs}"] = p_med / bs
        out[f"xgb_predict_iqr_half_ms_b{bs}"] = p_iqr / bs
    import platform
    out["xgb_hardware"] = f"CPU, one thread ({platform.processor() or platform.machine()})"
    if "proposed_ms_b1" in out:
        tot = (out["proposed_ms_b1"] + out.get("retrieval_only_ms_b1", 0) + out["xgb_features_ms_per_window_b1"]
               + out["xgb_predict_ms_per_window_b1"] + out.get("projection_only_ms_b1", 0))
        out["hybrid_total_ms_per_window_b1"] = tot
        out["hybrid_total_note"] = ("LLM branch forward + retrieval + projection (GPU, main run) + XGBoost features and "
                                    "prediction (CPU, one thread); branches run in sequence, so this is an upper bound")
    out["gpu_available_now"] = bool(torch.cuda.is_available())
    return out
