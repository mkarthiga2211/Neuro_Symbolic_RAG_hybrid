"""Merged hourly corpus, scaling on the training partition only, chronological 70:15:15 split, windows."""
import numpy as np
import pandas as pd

from . import embed_retrieve as ER
from . import utils as U


class Data:
    """Holds the hourly arrays and builds model inputs for any set of forecast origins."""

    def __init__(self, cfg, arrays_path, emb_path, retr_paths):
        self.cfg = cfg
        z = np.load(arrays_path, allow_pickle=False)
        for k in z.files:
            setattr(self, k, z[k])
        self.H = cfg.horizon
        self.ts = pd.to_datetime(self.ts_ns)
        self.days = pd.to_datetime(self.days_ns)
        self.emb_path = emb_path
        self.retr_paths = retr_paths
        self._ctx_cache = {}
        self.C_mw = float(self.cap_mw)
        self.C = float((self.cap_mw - self.load_min) / (self.load_max - self.load_min))

    # ---------------------------------------------------------------- scaling
    def to_mw(self, x):
        return x * (self.load_max - self.load_min) + self.load_min

    def to_scaled(self, x):
        return (x - self.load_min) / (self.load_max - self.load_min)

    # ----------------------------------------------------------------- context
    def ctx(self, variant="matched", K=None, seed=0):
        """Per-issue-day context vectors for a variant. Variants: matched, sameday, control_country,
        shuffled, shift365, zero."""
        K = K or self.cfg.top_k
        key = (variant, K, seed)
        if key in self._ctx_cache:
            return self._ctx_cache[key]
        if variant in ("matched", "sameday", "control_country"):
            c, _ = ER.context_vectors(self.cfg, self.emb_path, self.retr_paths[variant], K)
        elif variant == "zero":
            c, _ = ER.context_vectors(self.cfg, self.emb_path, self.retr_paths["matched"], K)
            c = np.zeros_like(c)
        elif variant == "shuffled":
            base, _ = ER.context_vectors(self.cfg, self.emb_path, self.retr_paths["matched"], K)
            c = base.copy()
            test_days = np.unique(self.day_of_hour[self.origins_test])
            rng = np.random.default_rng(1000 + seed)
            perm = rng.permutation(test_days)
            c[test_days] = base[perm]
        elif variant == "shift365":
            base, _ = ER.context_vectors(self.cfg, self.emb_path, self.retr_paths["matched"], K)
            c = np.zeros_like(base)
            c[365:] = base[:-365]
        else:
            raise ValueError(variant)
        self._ctx_cache[key] = c.astype(np.float32)
        return self._ctx_cache[key]

    def tone_for(self, variant):
        return self.tone_sameday if variant == "sameday" else self.tone_lag

    # ------------------------------------------------------------------ inputs
    def inputs(self, origins, w, ctx_variant="matched", K=None, seed=0, label_len=48):
        H = self.H
        o = np.asarray(origins)
        hist = o[:, None] + np.arange(-w + 1, 1)[None, :]
        fut = o[:, None] + np.arange(1, H + 1)[None, :]
        d = self.day_of_hour[o]
        out = {
            "x_load": self.load_s[hist], "x_temp": self.temp_z[hist],
            "f_temp": self.temp_z[fut] if self.cfg.use_future_temperature else np.zeros((len(o), H), np.float32),
            "tone": self.tone_for(ctx_variant)[d][:, None],
            "ctx": self.ctx(ctx_variant, K, seed)[d],
            "mark_hist": self.marks[hist], "mark_fut": self.marks[fut],
            "y": self.load_s[fut],
        }
        return {k: v.astype(np.float32) for k, v in out.items()}

    def y_mw(self, origins):
        fut = np.asarray(origins)[:, None] + np.arange(1, self.H + 1)[None, :]
        return self.load_mw[fut]


def build_arrays(cfg, load_df, daily_path, retr_paths):
    out = cfg.path("data", "processed", "arrays.npz")
    out_facts = cfg.path("data", "processed", "split_facts.json")

    def _run():
        df = load_df.copy()
        N = len(df)
        n_tr = int(round(cfg.split[0] * N))
        n_va = int(round(cfg.split[1] * N))
        load = df["load"].values.astype(np.float64)
        temp = df["temp_c"].values.astype(np.float64)
        lmin, lmax = load[:n_tr].min(), load[:n_tr].max()
        tmu, tsd = temp[:n_tr].mean(), temp[:n_tr].std()
        temp_z = np.clip((temp - tmu) / tsd, -cfg.temp_cap_sd, cfg.temp_cap_sd)
        cap = np.percentile(load[:n_tr], cfg.cap_percentile) * cfg.cap_factor
        ts = df.index
        day0 = ts[0].normalize()
        days = pd.date_range(day0, ts[-1].normalize(), freq="D")
        day_of_hour = ((ts.normalize() - day0).days).values.astype(np.int64)
        # daily GDELT features for the matched country
        daily = pd.read_parquet(daily_path)
        dus = daily[daily["country"] == cfg.country].set_index("date").reindex(days)
        n_rec = dus["n_records"].fillna(0).values
        tone = dus["mean_tone"].values
        tr_days = np.unique(day_of_hour[:n_tr])
        t_mu, t_sd = np.nanmean(tone[tr_days]), np.nanstd(tone[tr_days])
        tone_z = np.nan_to_num((tone - t_mu) / (t_sd if t_sd > 0 else 1.0), nan=0.0)
        L = cfg.publication_lag_days
        tone_lag = np.zeros_like(tone_z)
        tone_lag[L:] = tone_z[:-L] if L > 0 else tone_z
        n_rec_lag = np.zeros_like(n_rec)
        n_rec_lag[L:] = n_rec[:-L] if L > 0 else n_rec
        n_grid = dus["n_grid_kw"].fillna(0).values
        n_grid_lag = np.zeros_like(n_grid)
        n_grid_lag[L:] = n_grid[:-L] if L > 0 else n_grid
        # calendar marks (Informer)
        marks = np.stack([ts.hour / 23.0 - 0.5, ts.dayofweek / 6.0 - 0.5,
                          (ts.day - 1) / 30.0 - 0.5, (ts.dayofyear - 1) / 365.0 - 0.5], 1)
        # origins: all 24 targets inside the partition, history inside the data
        H, wmax = cfg.horizon, cfg.max_window
        def origins(lo, hi):
            o = np.arange(max(lo - 1, wmax - 1), hi - H, cfg.origin_stride)
            return o[o + H < hi + 0]  # targets o+1..o+H < hi
        o_tr = origins(0, n_tr)
        o_va = origins(n_tr, n_tr + n_va)
        o_te = origins(n_tr + n_va, N)
        # retrieval validity per day (matched)
        rv = np.load(retr_paths["matched"])["valid"]
        np.savez(out + ".tmp.npz",
                 load_s=((load - lmin) / (lmax - lmin)).astype(np.float32),
                 load_mw=load.astype(np.float32), temp_c=temp.astype(np.float32),
                 temp_z=temp_z.astype(np.float32), ts_ns=ts.values.astype("datetime64[ns]").astype(np.int64),
                 days_ns=days.values.astype("datetime64[ns]").astype(np.int64),
                 day_of_hour=day_of_hour, tone_lag=tone_lag.astype(np.float32),
                 tone_sameday=tone_z.astype(np.float32), n_rec=n_rec.astype(np.float32),
                 n_rec_lag=n_rec_lag.astype(np.float32), n_grid_lag=n_grid_lag.astype(np.float32),
                 marks=marks.astype(np.float32), origins_train=o_tr, origins_val=o_va, origins_test=o_te,
                 load_min=np.float64(lmin), load_max=np.float64(lmax), cap_mw=np.float64(cap),
                 temp_mu=np.float64(tmu), temp_sd=np.float64(tsd), n_train_hours=np.int64(n_tr),
                 n_val_hours=np.int64(n_va), ctx_valid=rv)
        import os
        os.replace(out + ".tmp.npz", out)
        test_days = np.unique(day_of_hour[o_te])
        facts = {
            "n_hours": int(N), "train_hours": int(n_tr), "val_hours": int(n_va), "test_hours": int(N - n_tr - n_va),
            "train_period": f"{ts[0]} to {ts[n_tr - 1]}", "val_period": f"{ts[n_tr]} to {ts[n_tr + n_va - 1]}",
            "test_period": f"{ts[n_tr + n_va]} to {ts[-1]}",
            "n_train_windows": int(len(o_tr)), "n_val_windows": int(len(o_va)), "n_test_windows": int(len(o_te)),
            "origin_stride_hours": cfg.origin_stride,
            "capacity_C_mw": float(cap), "train_p91_mw": float(np.percentile(load[:n_tr], cfg.cap_percentile)),
            "train_max_mw": float(lmax), "test_max_mw": float(load[n_tr + n_va:].max()),
            "share_test_hours_above_C": float((load[n_tr + n_va:] > cap).mean() * 100),
            "share_days_with_context_test": float(rv[test_days].mean() * 100),
            "mean_hourly_load_mw": float(load.mean()),
        }
        U.atomic_write_json(out_facts, facts)
        U.log(f"Split: {facts['n_train_windows']} / {facts['n_val_windows']} / {facts['n_test_windows']} windows; "
              f"C = {cap:.1f} MW; {facts['share_test_hours_above_C']:.2f}% of test hours above C")
        if facts["share_test_hours_above_C"] < 0.1:
            U.warn("Real load almost never exceeds C = P91 x 1.35. Expect near-zero violation rates for every "
                   "model, so the symbolic layer will change little. Report this as found.")

    U.stage("arrays", [out, out_facts], _run)
    return out, U.read_json(out_facts)


class Batches:
    """Shuffled mini-batches over origins with a saveable torch.Generator."""

    def __init__(self, origins, batch_size, shuffle, seed):
        import torch
        self.origins = np.asarray(origins)
        self.bs = batch_size
        self.shuffle = shuffle
        self.gen = torch.Generator().manual_seed(seed)

    def __iter__(self):
        import torch
        n = len(self.origins)
        order = torch.randperm(n, generator=self.gen).numpy() if self.shuffle else np.arange(n)
        for i in range(0, n, self.bs):
            yield self.origins[order[i:i + self.bs]]

    def __len__(self):
        return (len(self.origins) + self.bs - 1) // self.bs
