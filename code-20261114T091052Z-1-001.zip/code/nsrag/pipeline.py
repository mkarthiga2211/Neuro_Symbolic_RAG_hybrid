"""One function per notebook step. Every step is safe to rerun: finished work is skipped."""
import os
from types import SimpleNamespace

import pandas as pd

from . import analysis as AN
from . import baselines_classic as BC
from . import data_gdelt as GD
from . import data_gefcom as GF
from . import dataset as DS
from . import embed_retrieve as ER
from . import experiments as X
from . import latency as LT
from . import report as RP
from . import tune as TU
from . import utils as U


def prepare(cfg):
    """Data stages 1 to 6. On rerun everything is loaded from Drive in about a minute."""
    U.log("== Step 1: GEFCom2014 load and temperature")
    load_df, facts_load = GF.build(cfg)
    start = (load_df.index[0].normalize() - pd.Timedelta(days=2)).date()
    end = load_df.index[-1].date()
    U.log(f"== Step 2: GDELT 1.0 files for {start} to {end}")
    names, _ = GD.download_and_filter(cfg, start, end)
    U.log("== Step 3: GDELT text, deduplication, daily tone and counts")
    rec_path, daily_path, facts_gdelt = GD.build_records(cfg, names)
    U.log("== Step 4: sentence embeddings")
    rec_tid, emb = ER.build_embeddings(cfg, rec_path)
    days = pd.date_range(load_df.index[0].normalize(), load_df.index[-1].normalize(), freq="D")
    U.log("== Step 5: retrieval of contextual twins")
    retr = ER.build_retrieval(cfg, rec_tid, emb, days)
    U.log("== Step 6: merged corpus, scaling, chronological split")
    arrays, facts_split = DS.build_arrays(cfg, load_df, daily_path, retr)
    data = DS.Data(cfg, arrays, emb, retr)
    return SimpleNamespace(cfg=cfg, data=data, emb=emb, retr=retr, rec_tid=rec_tid, rec_path=rec_path,
                           text_ids=cfg.path("cache", "text_ids.parquet"), facts_load=facts_load,
                           facts_gdelt=facts_gdelt, facts_split=facts_split)


def descriptive_figures(S):
    """Figures 2 to 5 and the data facts of Block G. Can run before any training."""
    return AN.block_g(S.cfg, S.data, S.emb, S.rec_tid)


def tune_all(S, models=None):
    for m in (models or [m for m in S.cfg.tune_models if m != "xgb_text"]):
        U.log(f"== Tuning {m}: {S.cfg.tune_trials} trials, at most {S.cfg.tune_max_epochs} epochs each")
        TU.tune(S.cfg, S.data, m)


def train_main(S, models=None):
    X.run_main(S.cfg, S.data, models)


def train_ablations(S):
    X.run_ablations(S.cfg, S.data)
    X.run_topk(S.cfg, S.data)


def classic_baselines(S):
    BC.run_xgb(S.cfg, S.data, S.cfg.seeds)
    if S.cfg.run_arima:
        BC.run_arima(S.cfg, S.data)
    if S.cfg.run_prophet:
        try:
            BC.run_prophet(S.cfg, S.data)
        except ImportError:
            U.warn("prophet is not installed; Prophet skipped")


def analysis(S):
    G = AN.block_g(S.cfg, S.data, S.emb, S.rec_tid)
    extra_p = S.cfg.path("results", "raw", "blockG_extra.json")
    if not (U.is_done("shap_umap") and os.path.exists(extra_p)):
        extra = AN.shap_and_umap(S.cfg, S.data, S.emb, S.retr, S.text_ids)
        U.atomic_write_json(extra_p, extra)
        U.mark_done("shap_umap")
    else:
        U.log("[skip] SHAP and UMAP")
    return G


def latency(S):
    return LT.run(S.cfg, S.data, S.emb, S.retr)


def report(S):
    return RP.build_all(S.cfg, S.data, S.facts_load, S.facts_gdelt, S.facts_split)


def hybrid(S):
    """Hybrid NS-RAG (LLM branch + XGBoost branch, projected) from the saved forecasts; no retraining."""
    from . import hybrid as HY
    return HY.run(S)
