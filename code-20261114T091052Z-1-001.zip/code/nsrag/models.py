"""Models. Every model maps a batch dict to a raw 24-hour forecast in scaled units (min-max of training load).

All neural models get the same inputs: load history, temperature history, temperature of the 24 target
hours (if cfg.use_future_temperature), and the lagged daily GDELT tone. Only the proposed model family also
gets the retrieved context vector c_t.
"""
import math

import torch
import torch.nn as nn
import torch.nn.functional as F


_PRETRAINED = {}


def load_pretrained(name):
    """Load a Hugging Face backbone once per session and hand out copies (no repeated disk reads)."""
    import copy
    from transformers import AutoModel
    if name not in _PRETRAINED:
        _PRETRAINED[name] = AutoModel.from_pretrained(name)
    return copy.deepcopy(_PRETRAINED[name])


def n_params(model, trainable_only=False):
    return sum(p.numel() for p in model.parameters() if p.requires_grad or not trainable_only)


# ====================================================================== proposed
class NSRAG(nn.Module):
    """Patch time-series encoder f_ts (Eq. 7) + projected context c_t (Eq. 10-11) as tokens of a
    DistilBERT forecasting head f_theta (Eq. 12) + two-layer MLP to 24 outputs.
    use_ctx=False gives the vanilla / base LLM with the same backbone."""

    def __init__(self, w, patch=24, d=768, ts_layers=2, head_hidden=256, use_ctx=True, ctx_dim=384,
                 backbone="distilbert-base-uncased", horizon=24, pretrained=True):
        super().__init__()
        from transformers import AutoConfig, AutoModel
        assert w % patch == 0, "window must be a multiple of the patch length"
        self.patch, self.n_patch, self.use_ctx = patch, w // patch, use_ctx
        if pretrained:
            self.lm = load_pretrained(backbone)
        else:
            self.lm = AutoModel.from_config(AutoConfig.from_pretrained(backbone))
        d_lm = self.lm.config.hidden_size if hasattr(self.lm.config, "hidden_size") else self.lm.config.dim
        self.patch_embed = nn.Linear(2 * patch, d)
        self.pos = nn.Parameter(torch.zeros(1, self.n_patch, d))
        layer = nn.TransformerEncoderLayer(d, nhead=8, dim_feedforward=2 * d, dropout=0.1, batch_first=True,
                                           norm_first=True)
        self.ts_encoder = nn.TransformerEncoder(layer, ts_layers)
        self.to_lm = nn.Identity() if d == d_lm else nn.Linear(d, d_lm)
        self.fut_embed = nn.Linear(horizon, d_lm)
        self.tone_embed = nn.Linear(1, d_lm)
        self.ctx_proj = nn.Linear(ctx_dim, d_lm) if use_ctx else None
        self.cls = nn.Parameter(torch.randn(1, 1, d_lm) * 0.02)
        self.head = nn.Sequential(nn.Linear(d_lm, head_hidden), nn.GELU(), nn.Dropout(0.1),
                                  nn.Linear(head_hidden, horizon))

    def forward(self, b):
        B = b["x_load"].shape[0]
        x = torch.stack([b["x_load"], b["x_temp"]], -1)                       # B, w, 2
        x = x.reshape(B, self.n_patch, self.patch * 2)
        h = self.ts_encoder(self.patch_embed(x) + self.pos)                    # h_t, Eq. 7
        toks = [self.cls.expand(B, -1, -1), self.to_lm(h),
                self.fut_embed(b["f_temp"]).unsqueeze(1), self.tone_embed(b["tone"]).unsqueeze(1)]
        if self.use_ctx:
            toks.append(self.ctx_proj(b["ctx"]).unsqueeze(1))                  # projected c_t, Eq. 11
        z = torch.cat(toks, 1)
        out = self.lm(inputs_embeds=z).last_hidden_state[:, 0]
        return self.head(out)                                                   # raw forecast, Eq. 12


# ====================================================================== DLinear
class DLinear(nn.Module):
    def __init__(self, w, kernel=25, horizon=24):
        super().__init__()
        self.kernel = kernel
        self.seasonal = nn.Linear(w, horizon)
        self.trend = nn.Linear(w, horizon)
        self.exo = nn.Linear(horizon + 1 + w, horizon)

    def forward(self, b):
        x = b["x_load"]
        pad = (self.kernel - 1) // 2
        xp = F.pad(x.unsqueeze(1), (pad, self.kernel - 1 - pad), mode="replicate")
        trend = F.avg_pool1d(xp, self.kernel, stride=1).squeeze(1)
        seas = x - trend
        exo = torch.cat([b["f_temp"], b["tone"], b["x_temp"]], 1)
        return self.seasonal(seas) + self.trend(trend) + self.exo(exo)


# ====================================================================== PatchTST
class PatchTST(nn.Module):
    """Channel-independent patch transformer on load and temperature, flatten head, linear covariate head."""

    def __init__(self, w, patch=24, d_model=128, n_layers=3, n_heads=8, dropout=0.1, horizon=24):
        super().__init__()
        self.patch, self.stride = patch, max(1, patch // 2)
        self.n_patch = (w - patch) // self.stride + 2          # with end padding, as in PatchTST
        self.embed = nn.Linear(patch, d_model)
        self.pos = nn.Parameter(torch.randn(1, self.n_patch, d_model) * 0.02)
        layer = nn.TransformerEncoderLayer(d_model, n_heads, 2 * d_model, dropout, batch_first=True,
                                           norm_first=True)
        self.enc = nn.TransformerEncoder(layer, n_layers)
        self.head = nn.Linear(2 * self.n_patch * d_model, horizon)
        self.exo = nn.Linear(horizon + 1, horizon)
        self.drop = nn.Dropout(dropout)

    def _encode(self, x):
        mu = x.mean(1, keepdim=True)
        sd = x.std(1, keepdim=True) + 1e-5
        xn = (x - mu) / sd
        xn = F.pad(xn.unsqueeze(1), (0, self.stride), mode="replicate").squeeze(1)
        p = xn.unfold(1, self.patch, self.stride)                               # B, n_patch, patch
        z = self.enc(self.embed(p) + self.pos)
        return z.flatten(1), mu, sd

    def forward(self, b):
        zl, mu, sd = self._encode(b["x_load"])
        zt, _, _ = self._encode(b["x_temp"])
        y = self.head(self.drop(torch.cat([zl, zt], 1)))
        y = y * sd + mu
        return y + self.exo(torch.cat([b["f_temp"], b["tone"]], 1))


# ====================================================================== Informer
class ProbAttention(nn.Module):
    """ProbSparse self-attention (Zhou et al., 2021)."""

    def __init__(self, factor=5, dropout=0.1):
        super().__init__()
        self.factor = factor
        self.drop = nn.Dropout(dropout)

    def forward(self, q, k, v):                                    # B, H, L, D
        B, H, Lq, D = q.shape
        Lk = k.shape[2]
        u_k = min(Lk, int(self.factor * math.ceil(math.log(Lk + 1))))
        u_q = min(Lq, int(self.factor * math.ceil(math.log(Lq + 1))))
        idx = torch.randint(Lk, (Lq, u_k), device=q.device)
        k_sample = k[:, :, idx, :]                                  # B, H, Lq, u_k, D
        qk_sample = (q.unsqueeze(-2) @ k_sample.transpose(-2, -1)).squeeze(-2)
        M = qk_sample.max(-1)[0] - qk_sample.sum(-1) / Lk
        top = M.topk(u_q, dim=-1, sorted=False)[1]                  # B, H, u_q
        q_red = torch.gather(q, 2, top.unsqueeze(-1).expand(-1, -1, -1, D))
        scores = (q_red @ k.transpose(-2, -1)) / math.sqrt(D)
        attn = self.drop(torch.softmax(scores, -1))
        ctx = v.mean(2, keepdim=True).expand(B, H, Lq, D).clone()
        ctx.scatter_(2, top.unsqueeze(-1).expand(-1, -1, -1, D), (attn @ v).to(ctx.dtype))
        return ctx


class AttnLayer(nn.Module):
    def __init__(self, d, h, prob=True, causal=False, factor=5, dropout=0.1):
        super().__init__()
        self.h, self.prob, self.causal = h, prob, causal
        self.q, self.k, self.v, self.o = (nn.Linear(d, d) for _ in range(4))
        self.inner = ProbAttention(factor, dropout) if prob else None
        self.drop = nn.Dropout(dropout)

    def forward(self, x, mem=None):
        mem = x if mem is None else mem
        B, L, d = x.shape
        S = mem.shape[1]
        q = self.q(x).view(B, L, self.h, -1).transpose(1, 2)
        k = self.k(mem).view(B, S, self.h, -1).transpose(1, 2)
        v = self.v(mem).view(B, S, self.h, -1).transpose(1, 2)
        if self.prob:
            o = self.inner(q, k, v)
        else:
            o = F.scaled_dot_product_attention(q, k, v, is_causal=self.causal,
                                               dropout_p=self.drop.p if self.training else 0.0)
        return self.o(o.transpose(1, 2).reshape(B, L, d))


class Informer(nn.Module):
    """Compact Informer: ProbSparse encoder with distilling, generative-style decoder (start token)."""

    def __init__(self, w, d_model=512, e_layers=2, d_layers=1, n_heads=8, factor=5, dropout=0.05,
                 label_len=48, horizon=24, c_in=3, mark_dim=4):
        super().__init__()
        self.label_len, self.H = label_len, horizon
        self.enc_tok = nn.Conv1d(c_in, d_model, 3, padding=1, padding_mode="circular")
        self.dec_tok = nn.Conv1d(c_in, d_model, 3, padding=1, padding_mode="circular")
        self.enc_mark = nn.Linear(mark_dim, d_model)
        self.dec_mark = nn.Linear(mark_dim, d_model)
        self.register_buffer("pe", self._pe(w + label_len + horizon, d_model), persistent=False)
        self.enc_attn = nn.ModuleList([AttnLayer(d_model, n_heads, True, False, factor, dropout)
                                       for _ in range(e_layers)])
        self.enc_ff = nn.ModuleList([self._ff(d_model, dropout) for _ in range(e_layers)])
        self.enc_n1 = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(e_layers)])
        self.enc_n2 = nn.ModuleList([nn.LayerNorm(d_model) for _ in range(e_layers)])
        self.distil = nn.ModuleList([nn.Sequential(
            nn.Conv1d(d_model, d_model, 3, padding=1, padding_mode="circular"), nn.BatchNorm1d(d_model),
            nn.ELU(), nn.MaxPool1d(3, 2, 1)) for _ in range(e_layers - 1)])
        self.enc_norm = nn.LayerNorm(d_model)
        self.dec_self = nn.ModuleList([AttnLayer(d_model, n_heads, False, True, factor, dropout)
                                       for _ in range(d_layers)])
        self.dec_cross = nn.ModuleList([AttnLayer(d_model, n_heads, False, False, factor, dropout)
                                        for _ in range(d_layers)])
        self.dec_ff = nn.ModuleList([self._ff(d_model, dropout) for _ in range(d_layers)])
        self.dec_n = nn.ModuleList([nn.ModuleList([nn.LayerNorm(d_model) for _ in range(3)])
                                    for _ in range(d_layers)])
        self.dec_norm = nn.LayerNorm(d_model)
        self.out = nn.Linear(d_model, 1)
        self.drop = nn.Dropout(dropout)

    @staticmethod
    def _ff(d, p):
        return nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Dropout(p), nn.Linear(4 * d, d))

    @staticmethod
    def _pe(n, d):
        pe = torch.zeros(n, d)
        pos = torch.arange(n).unsqueeze(1).float()
        div = torch.exp(torch.arange(0, d, 2).float() * (-math.log(10000.0) / d))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        return pe.unsqueeze(0)

    def forward(self, b):
        B, w = b["x_load"].shape
        tone = b["tone"].expand(-1, w)
        x_enc = torch.stack([b["x_load"], b["x_temp"], tone], -1)
        L = self.label_len
        dec_load = torch.cat([b["x_load"][:, -L:], torch.zeros_like(b["f_temp"])], 1)
        dec_temp = torch.cat([b["x_temp"][:, -L:], b["f_temp"]], 1)
        x_dec = torch.stack([dec_load, dec_temp, b["tone"].expand(-1, L + self.H)], -1)
        mark_dec = torch.cat([b["mark_hist"][:, -L:], b["mark_fut"]], 1)
        e = self.enc_tok(x_enc.transpose(1, 2)).transpose(1, 2) + self.enc_mark(b["mark_hist"]) + self.pe[:, :w]
        e = self.drop(e)
        for i in range(len(self.enc_attn)):
            e = self.enc_n1[i](e + self.drop(self.enc_attn[i](e)))
            e = self.enc_n2[i](e + self.drop(self.enc_ff[i](e)))
            if i < len(self.distil):
                e = self.distil[i](e.transpose(1, 2)).transpose(1, 2)
        e = self.enc_norm(e)
        x = self.dec_tok(x_dec.transpose(1, 2)).transpose(1, 2) + self.dec_mark(mark_dec) + self.pe[:, :L + self.H]
        x = self.drop(x)
        for i in range(len(self.dec_self)):
            n1, n2, n3 = self.dec_n[i]
            x = n1(x + self.drop(self.dec_self[i](x)))
            x = n2(x + self.drop(self.dec_cross[i](x, e)))
            x = n3(x + self.drop(self.dec_ff[i](x)))
        x = self.dec_norm(x)
        return self.out(x[:, -self.H:]).squeeze(-1)


# ====================================================================== Time-LLM
class TimeLLM(nn.Module):
    """Compact Time-LLM (Jin et al., 2024): patches reprogrammed onto text prototypes of a frozen GPT-2,
    a fixed prompt prefix, and an output projection. A linear covariate head adds temperature and tone."""

    def __init__(self, w, patch=16, n_proto=1000, d_model=32, n_heads=8, backbone="gpt2", horizon=24,
                 pretrained=True, d_ff=128, prompt=None):
        super().__init__()
        from transformers import AutoConfig, AutoModel, AutoTokenizer
        self.llm = load_pretrained(backbone) if pretrained else \
            AutoModel.from_config(AutoConfig.from_pretrained(backbone))
        for p in self.llm.parameters():
            p.requires_grad = False
        d_llm = self.llm.config.hidden_size if hasattr(self.llm.config, "hidden_size") else self.llm.config.n_embd
        wte = self.llm.get_input_embeddings().weight                         # V, d_llm (frozen)
        self.register_buffer("word_emb", wte.detach().clone(), persistent=False)
        self.patch, self.stride = patch, max(1, patch // 2)
        self.n_patch = (w - patch) // self.stride + 2
        self.patch_embed = nn.Linear(patch, d_model)
        self.mapping = nn.Linear(wte.shape[0], n_proto)                       # vocabulary -> text prototypes
        self.n_heads = n_heads
        self.q = nn.Linear(d_model, d_llm)
        self.k = nn.Linear(d_llm, d_llm)
        self.v = nn.Linear(d_llm, d_llm)
        self.o = nn.Linear(d_llm, d_llm)
        self.d_ff = min(d_ff, d_llm)
        self.head = nn.Linear(self.n_patch * self.d_ff, horizon)
        self.exo = nn.Linear(horizon + 1, horizon)
        prompt = prompt or ("Dataset description: hourly electricity load of a United States utility "
                            "(GEFCom2014). Task description: forecast the next 24 hours from the previous "
                            f"{w} hours. Input statistics are normalised per window.")
        try:
            tok = AutoTokenizer.from_pretrained(backbone)
            ids = tok(prompt, return_tensors="pt")["input_ids"][0]
        except Exception:  # noqa: BLE001 (offline tests)
            ids = torch.arange(16) % wte.shape[0]
        self.register_buffer("prompt_ids", ids, persistent=False)

    def forward(self, b):
        x = b["x_load"]
        B = x.shape[0]
        mu, sd = x.mean(1, keepdim=True), x.std(1, keepdim=True) + 1e-5
        xn = F.pad(((x - mu) / sd).unsqueeze(1), (0, self.stride), mode="replicate").squeeze(1)
        p = self.patch_embed(xn.unfold(1, self.patch, self.stride))           # B, P, d_model
        proto = self.mapping(self.word_emb.T).T                               # n_proto, d_llm
        H = self.n_heads
        q = self.q(p).view(B, self.n_patch, H, -1).transpose(1, 2)
        k = self.k(proto).view(1, -1, H, q.shape[-1]).transpose(1, 2).expand(B, -1, -1, -1)
        v = self.v(proto).view(1, -1, H, q.shape[-1]).transpose(1, 2).expand(B, -1, -1, -1)
        rep = F.scaled_dot_product_attention(q, k, v).transpose(1, 2).reshape(B, self.n_patch, -1)
        rep = self.o(rep)
        prefix = self.llm.get_input_embeddings()(self.prompt_ids).unsqueeze(0).expand(B, -1, -1)
        z = torch.cat([prefix.to(rep.dtype), rep], 1)
        out = self.llm(inputs_embeds=z).last_hidden_state[:, -self.n_patch:, :self.d_ff]
        y = self.head(out.reshape(B, -1)) * sd + mu
        return y + self.exo(torch.cat([b["f_temp"], b["tone"]], 1))


# ====================================================================== factory
def build(name, hp, cfg, pretrained=True):
    w = hp.get("w", cfg.window)
    if name in ("proposed", "rag_only", "pen_only", "sym_only", "proposed_sameday", "vanilla"):
        return NSRAG(w, patch=cfg.patch, d=cfg.ts_hidden, ts_layers=cfg.ts_layers, head_hidden=cfg.head_hidden,
                     use_ctx=(name != "vanilla" and name != "pen_only" and name != "sym_only"),
                     backbone=cfg.lm_backbone, horizon=cfg.horizon, pretrained=pretrained)
    if name in ("informer", "informer_c"):
        return Informer(w, d_model=hp.get("d_model", 512), e_layers=hp.get("layers", 2), horizon=cfg.horizon)
    if name == "patchtst":
        return PatchTST(w, patch=hp.get("patch", 24), d_model=hp.get("d_model", 128),
                        n_layers=hp.get("layers", 3), horizon=cfg.horizon)
    if name == "dlinear":
        return DLinear(w, kernel=hp.get("kernel", 25), horizon=cfg.horizon)
    if name == "timellm":
        return TimeLLM(w, patch=hp.get("patch", 16), n_proto=hp.get("prototypes", 1000),
                       backbone=cfg.timellm_backbone, horizon=cfg.horizon, pretrained=pretrained)
    raise ValueError(name)
