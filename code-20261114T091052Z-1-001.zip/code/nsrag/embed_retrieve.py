"""Sentence embeddings of the GDELT corpus (sharded, resumable) and top-K retrieval for every day.

Retrieval for issue day D with lag L: the query is the mean embedding of the records of day q = D - L;
the corpus is every unique text first seen before day q (so nothing from the query day or later is
retrieved). Top-kmax neighbours are stored once; the context vector for any K <= kmax is built from them.
"""
import math
import os

import numpy as np
import pandas as pd

from . import utils as U


_ENCODER = None


def embed_texts(cfg, texts):
    """Encode texts with the frozen sentence encoder (L2-normalised, float16). Tests replace this function."""
    global _ENCODER
    from sentence_transformers import SentenceTransformer
    import torch
    if _ENCODER is None:
        _ENCODER = SentenceTransformer(cfg.text_encoder, device=str(U.device()))
        if torch.cuda.is_available():
            _ENCODER = _ENCODER.half()
    return _ENCODER.encode(texts, batch_size=cfg.embed_batch, convert_to_numpy=True,
                           normalize_embeddings=True, show_progress_bar=False).astype(np.float16)


def build_embeddings(cfg, rec_path):
    tid_path = cfg.path("cache", "text_ids.parquet")
    rec_tid_path = cfg.path("cache", "records_tid.parquet")
    emb_path = cfg.path("cache", "embeddings_f16.npy")

    def _ids():
        rec = pd.read_parquet(rec_path)
        uniq = pd.Index(rec["text"].unique())
        U.atomic_to_parquet(pd.DataFrame({"tid": np.arange(len(uniq)), "text": uniq}), tid_path)
        rec["tid"] = uniq.get_indexer(rec["text"]).astype(np.int64)
        U.atomic_to_parquet(rec.drop(columns=["text"]), rec_tid_path)
        U.log(f"{len(uniq)} unique texts to embed")

    U.stage("text_ids", [tid_path, rec_tid_path], _ids)

    def _embed():
        texts = pd.read_parquet(tid_path)["text"].tolist()
        n = len(texts)
        n_shards = math.ceil(n / cfg.embed_shard)
        est_min = n / 3000 / 60
        U.log(f"Embedding {n} texts in {n_shards} shards (about {est_min:.0f} min on a T4)")
        shard_dir = cfg.path("cache", "emb_shards")
        os.makedirs(shard_dir, exist_ok=True)
        for s in range(n_shards):
            p = os.path.join(shard_dir, f"shard_{s:04d}.npy")
            if os.path.exists(p):
                continue
            arr = embed_texts(cfg, texts[s * cfg.embed_shard:(s + 1) * cfg.embed_shard])
            U.atomic_save_npy(p, arr)
            U.log(f"[done] embedding shard {s + 1}/{n_shards}")
        out = np.lib.format.open_memmap(emb_path + ".tmp.npy", mode="w+", dtype=np.float16,
                                        shape=(n, np.load(os.path.join(shard_dir, "shard_0000.npy"),
                                                          mmap_mode="r").shape[1]))
        for s in range(n_shards):
            a = np.load(os.path.join(shard_dir, f"shard_{s:04d}.npy"))
            out[s * cfg.embed_shard: s * cfg.embed_shard + len(a)] = a
        out.flush()
        del out
        os.replace(emb_path + ".tmp.npy", emb_path)

    U.stage("embeddings", emb_path, _embed)
    return rec_tid_path, emb_path


def _day_queries(E, rec_c, days):
    """Mean embedding (normalised) of the records of each day. Returns (n_days, d) and a validity mask."""
    d = E.shape[1]
    Q = np.zeros((len(days), d), np.float32)
    valid = np.zeros(len(days), bool)
    day_pos = pd.Series(np.arange(len(days)), index=days)
    for date, g in rec_c.groupby("date"):
        if date not in day_pos.index:
            continue
        v = E[g["tid"].values].astype(np.float32).mean(0)
        nrm = np.linalg.norm(v)
        if nrm > 0:
            Q[day_pos[date]] = v / nrm
            valid[day_pos[date]] = True
    return Q, valid


def retrieve(cfg, E, rec_c, days, lag, kmax):
    """Top-kmax neighbours for every issue day. Returns ids (n_days, kmax), sims, valid."""
    import torch
    dev = U.device()
    first = rec_c.groupby("tid")["date"].min().sort_values()
    corpus_ids = first.index.values.astype(np.int64)
    first_day = first.values
    Qd, qvalid = _day_queries(E, rec_c, days)
    # issue day D uses the query of day D - lag
    shift = lag
    Q = np.zeros_like(Qd)
    valid = np.zeros(len(days), bool)
    if shift > 0:
        Q[shift:] = Qd[:-shift]
        valid[shift:] = qvalid[:-shift]
    else:
        Q, valid = Qd, qvalid
    qday = days - pd.Timedelta(days=lag)
    n_avail = np.searchsorted(first_day, qday.values, side="left")     # corpus texts first seen before q
    valid &= n_avail >= kmax
    ids = np.full((len(days), kmax), -1, np.int64)
    sims = np.full((len(days), kmax), -np.inf, np.float32)
    n = len(corpus_ids)
    on_gpu = dev.type == "cuda" and n * E.shape[1] * 2 < 4e9
    dtype = torch.float16 if dev.type == "cuda" else torch.float32
    chunk = 200_000
    chunks = []
    for s in range(0, n, chunk):
        c = torch.from_numpy(E[corpus_ids[s:s + chunk]].astype(np.float16 if dev.type == "cuda" else np.float32))
        chunks.append(c.to(dev) if on_gpu else c)
    qb = 256
    vidx = np.where(valid)[0]
    for b in range(0, len(vidx), qb):
        rows = vidx[b:b + qb]
        q = torch.from_numpy(Q[rows]).to(dev, dtype)
        best_s = torch.full((len(rows), kmax), -float("inf"), device=dev)
        best_i = torch.full((len(rows), kmax), -1, dtype=torch.long, device=dev)
        lim = torch.from_numpy(n_avail[rows]).to(dev)
        for ci, c in enumerate(chunks):
            c = c.to(dev, dtype)
            s = (q @ c.T).float()
            gidx = torch.arange(ci * chunk, ci * chunk + c.shape[0], device=dev)
            s = s.masked_fill(gidx[None, :] >= lim[:, None], -float("inf"))
            k = min(kmax, s.shape[1])
            ts, ti = s.topk(k, dim=1)
            cat_s = torch.cat([best_s, ts], 1)
            cat_i = torch.cat([best_i, ti + ci * chunk], 1)
            best_s, order = cat_s.topk(kmax, dim=1)
            best_i = cat_i.gather(1, order)
        ids[rows] = corpus_ids[best_i.cpu().numpy()]
        sims[rows] = best_s.cpu().numpy()
    return ids, sims, valid


def build_retrieval(cfg, rec_tid_path, emb_path, days):
    """Retrieval for the matched country (lag 1 and same-day) and the control country (lag 1)."""
    outs = {}
    variants = [("matched", cfg.country, cfg.publication_lag_days),
                ("sameday", cfg.country, 0),
                ("control_country", cfg.control_country, cfg.publication_lag_days)]
    for name, country, lag in variants:
        path = cfg.path("cache", f"retrieval_{name}.npz")
        outs[name] = path

        def _run(country=country, lag=lag, path=path):
            E = np.load(emb_path, mmap_mode="r")
            rec = pd.read_parquet(rec_tid_path, columns=["country", "date", "tid"])
            rec_c = rec[rec["country"] == country]
            if rec_c.empty:
                U.warn(f"No GDELT records for country {country}; its context will be zero")
                ids = np.full((len(days), cfg.retrieval_kmax), -1, np.int64)
                sims = np.zeros((len(days), cfg.retrieval_kmax), np.float32)
                valid = np.zeros(len(days), bool)
            else:
                ids, sims, valid = retrieve(cfg, E, rec_c, days, lag, cfg.retrieval_kmax)
            np.savez(path + ".tmp.npz", ids=ids, sims=sims, valid=valid,
                     days=days.values.astype("datetime64[D]").astype(np.int64))
            os.replace(path + ".tmp.npz", path)
            U.log(f"Retrieval {country} lag {lag}: {valid.mean() * 100:.1f}% of days have context")

        U.stage(f"retrieval_{name}", path, _run)
    return outs


def context_vectors(cfg, emb_path, retr_path, K, temperature=None):
    """Context vector c_d (Eq. 10) for every day from stored top-kmax neighbours."""
    E = np.load(emb_path, mmap_mode="r")
    z = np.load(retr_path)
    ids, sims, valid = z["ids"][:, :K], z["sims"][:, :K], z["valid"]
    T = temperature or cfg.retrieval_temperature
    ctx = np.zeros((len(ids), E.shape[1]), np.float32)
    v = np.where(valid)[0]
    if len(v):
        s = sims[v] / T
        w = np.exp(s - s.max(1, keepdims=True))
        w /= w.sum(1, keepdims=True)
        emb = E[ids[v].ravel()].astype(np.float32).reshape(len(v), K, -1)
        ctx[v] = (w[:, :, None] * emb).sum(1)
    return ctx, valid
