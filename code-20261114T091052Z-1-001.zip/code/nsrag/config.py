"""Central configuration for the NS-RAG rerun.

Every setting that the manuscript reports lives here. The values actually used
in a run are written to results/blockA_settings.csv, so the manuscript can be
filled from what ran, not from what was planned.
"""
from dataclasses import dataclass, field, asdict
import json
import os


@dataclass
class Config:
    # ------------------------------------------------------------------ paths
    project_dir: str = "/content/drive/MyDrive/NS_RAG_rerun"
    local_tmp: str = "/content/tmp_nsrag"          # fast local disk, wiped on disconnect

    # ------------------------------------------------------------------ seeds
    seeds: tuple = (0, 1, 2, 3, 4)
    single_run_seed: int = 0                        # seed for single-run figures and Top-K

    # ------------------------------------------------------------- GEFCom2014
    # Sources tried in order. A missing dataset stops the run; there is no synthetic fallback.
    gefcom_zip_name: str = "GEFCom2014.zip"         # put it in <project>/data/raw/ to skip downloads
    gefcom_urls: tuple = (
        "https://www.dropbox.com/s/pqenrr2mcvl0hk9/GEFCom2014.zip?dl=1",
    )
    kaggle_dataset: str = "cthngon/gefcom2014-dataset"
    gefcom_temp_unit: str = "F"                     # GEFCom2014 station temperatures are in Fahrenheit
    max_interp_gap_hours: int = 6                   # longer load gaps stop the run instead of being filled
    temp_cap_sd: float = 3.0                        # cap for z-scored temperature (Section 3.4.1)

    # -------------------------------------------------------------------- GDELT
    gdelt_source: str = "files"                     # "files" (no account needed) or "bigquery"
    gcp_project: str = ""                           # only for gdelt_source = "bigquery"
    gdelt_base_url: str = "http://data.gdeltproject.org/events/"
    country: str = "US"                             # ActionGeo_CountryCode (FIPS 10-4)
    control_country: str = "UK"                     # FIPS code of the United Kingdom, for the relevance control
    cameo_roots: tuple = ("14", "18", "19", "20")
    keywords: tuple = ("grid", "power", "electricity", "outage", "blackout", "heatwave",
                       "heat wave", "storm", "hurricane", "energy")
    grid_keywords: tuple = ("grid", "power", "electricity", "outage", "blackout", "utility")
    max_records_per_day: int = 300                  # retrieval corpus cap per day (top by NumMentions); None = all
    publication_lag_days: int = 1                   # one-day lag (Section 3.4.2)

    # --------------------------------------------------------------- encoders
    text_encoder: str = "sentence-transformers/all-MiniLM-L6-v2"
    lm_backbone: str = "distilbert-base-uncased"    # see README: Llama-3 does not fit Colab, see notes
    timellm_backbone: str = "gpt2"
    embed_batch: int = 512
    embed_shard: int = 100_000
    retrieval_kmax: int = 10
    retrieval_ks: tuple = (1, 3, 5, 10)
    retrieval_temperature: float = 1.0              # softmax over cosine similarities (Eq. 10)

    # ----------------------------------------------------------------- data split
    split: tuple = (0.70, 0.15, 0.15)
    horizon: int = 24
    max_window: int = 336                           # largest w in the search space; fixes window origins
    origin_stride: int = 1                          # hours between forecast origins (all splits)
    use_future_temperature: bool = True             # observed temperature of the 24 target hours as covariate

    # --------------------------------------------------------------- capacity C
    cap_percentile: float = 91.0
    cap_factor: float = 1.35

    # ------------------------------------------------------- proposed model (defaults)
    window: int = 168
    patch: int = 24
    ts_hidden: int = 768
    ts_layers: int = 2
    head_hidden: int = 256
    top_k: int = 5
    lam: float = 0.1
    lr: float = 1e-4
    weight_decay: float = 0.01
    batch_size: int = 32
    max_epochs: int = 30
    patience: int = 5
    amp: bool = True

    # ------------------------------------------------------------------ tuning
    tune_trials: int = 30
    tune_max_epochs: int = 10                       # per trial, with median pruning; report what you use
    tune_patience: int = 3
    tune_train_stride: int = 1                      # use every n-th training origin inside trials only (speed knob)
    tune_models: tuple = ("proposed", "vanilla", "informer", "informer_c",
                          "patchtst", "dlinear", "timellm", "xgb_text")

    # ------------------------------------------------------------ checkpoints
    keep_last_ckpts: int = 3
    keep_best_weights: str = "seed0"                # "all", "seed0" or "none" after a run is evaluated

    # --------------------------------------------------------------- analysis
    tier_quantiles: tuple = (0.25, 0.75)            # Low / Normal / Peak tiers (Figure 13)
    extreme_quantile: float = 0.95                  # extreme-event threshold (Figure 14)
    heatwave_quantile: float = 0.95                 # daily max temperature, training days
    high_activity_quantile: float = 0.90            # daily record count, training days (Figure 5)
    bootstrap_reps: int = 2000

    # ---------------------------------------------------------------- latency
    latency_runs: int = 1000
    latency_warmup: int = 50
    latency_runs_batch256: int = 100

    # ------------------------------------------------------------------ misc
    run_shap: bool = True
    run_umap: bool = True
    run_prophet: bool = True
    run_arima: bool = True

    # ------------------------------------------------------------------ derived
    def path(self, *parts):
        p = os.path.join(self.project_dir, *parts)
        return p

    def to_json(self):
        d = asdict(self)
        return json.dumps(d, indent=2, default=str)

    @classmethod
    def from_overrides(cls, **kw):
        c = cls()
        for k, v in kw.items():
            if not hasattr(c, k):
                raise KeyError(f"Unknown setting: {k}")
            setattr(c, k, v)
        return c
