"""Inference latency (Table S8): median ms per window after warm-up, batch 1 and batch 256."""
import os
import time

import numpy as np
import pandas as pd
import torch

from . import experiments as X
from . import train as T
from . import utils as U


def _time(fn, runs, warm, sync):
    for _ in range(warm):
        fn()
    ts = []
    for _ in range(runs):
        sync()
        t0 = time.perf_counter()
        fn()
        sync()
        ts.append((time.perf_counter() - t0) * 1000)
    ts = np.array(ts)
    return float(np.median(ts)), float((np.percentile(ts, 75) - np.percentile(ts, 25)) / 2)


def run(cfg, data, emb_path, retr_paths):
    out = cfg.path("results", "raw", "blockI_latency.csv")
    if U.is_done("latency") and os.path.exists(out):
        U.log("[skip] latency")
        return pd.read_csv(out)
    dev = U.device()
    sync = torch.cuda.synchronize if dev.type == "cuda" else (lambda: None)
    hw = torch.cuda.get_device_name(0) if dev.type == "cuda" else "CPU"
    s0 = cfg.single_run_seed
    rows = []
    o = data.origins_test
    for name in ["proposed", "vanilla", "informer", "patchtst", "dlinear", "timellm"]:
        run_dir = cfg.path("checkpoints", name, f"seed{s0}")
        if not os.path.exists(os.path.join(run_dir, "best.pt")):
            U.warn(f"latency: no weights for {name} seed {s0}; skipped")
            continue
        hp = X.best_hp(cfg, data, name)
        m = T.load_best(cfg, data, name, hp, run_dir)
        w, K = hp.get("w", cfg.window), hp.get("K", cfg.top_k)
        v = T.VARIANTS[name]["ctx"]
        res = {"model": name, "hardware": hw}
        for bs, runs in [(1, cfg.latency_runs), (256, cfg.latency_runs_batch256)]:
            b = {k: torch.from_numpy(a).to(dev) for k, a in data.inputs(o[:bs], w, v, K, s0).items()}

            def fwd():
                with torch.no_grad(), torch.autocast(dev.type, dtype=torch.float16, enabled=dev.type == "cuda"):
                    y = m(b)
                    if T.VARIANTS[name]["project"]:
                        y = T.project(y, (0.0, data.C))
                return y
            med, iqr = _time(fwd, runs, cfg.latency_warmup, sync)
            res[f"ms_per_window_b{bs}"] = med / bs
            res[f"iqr_half_b{bs}"] = iqr / bs
        res["n_params"] = sum(p.numel() for p in m.parameters())
        rows.append(res)
        del m
        U.free_gpu()
    # retrieval only: query embedding of one day's records is precomputed; time the top-K search + weighting
    z = np.load(retr_paths["matched"])
    E = np.load(emb_path, mmap_mode="r")
    n = min(len(E), 2_000_000)
    corpus = torch.from_numpy(np.asarray(E[:n])).to(dev, torch.float16 if dev.type == "cuda" else torch.float32)
    K = cfg.top_k
    for bs, runs in [(1, cfg.latency_runs), (256, cfg.latency_runs_batch256)]:
        q = corpus[:bs].clone()

        def ret():
            s = q @ corpus.T
            ts, ti = s.float().topk(K, 1)
            wts = torch.softmax(ts / cfg.retrieval_temperature, 1)
            return (wts.unsqueeze(-1) * corpus[ti].float()).sum(1)
        med, iqr = _time(ret, runs, cfg.latency_warmup, sync)
        rows.append({"model": "retrieval_only", "hardware": hw, f"ms_per_window_b{bs}": med / bs,
                     f"iqr_half_b{bs}": iqr / bs, "corpus_size": n})
    # projection only
    for bs, runs in [(1, cfg.latency_runs), (256, cfg.latency_runs_batch256)]:
        y = torch.rand(bs, 24, device=dev)
        med, iqr = _time(lambda: T.project(y, (0.0, data.C)), runs, cfg.latency_warmup, sync)
        rows.append({"model": "projection_only", "hardware": hw, f"ms_per_window_b{bs}": med / bs,
                     f"iqr_half_b{bs}": iqr / bs})
    # ARIMA: state propagation for one origin on one CPU core
    ssm_p = cfg.path("preds", "arima", "ssm.npz")
    if os.path.exists(ssm_p):
        torch.set_num_threads(1)
        zz = np.load(ssm_p)
        Tm, Z, a = zz["T"], zz["Z"], zz["a"][:, None]

        def fc():
            st = a
            for _ in range(24):
                st = Tm @ st
                Z @ st
        med, iqr = _time(fc, cfg.latency_runs, cfg.latency_warmup, lambda: None)
        rows.append({"model": "arima", "hardware": "CPU, one core", "ms_per_window_b1": med, "iqr_half_b1": iqr,
                     "note": "Kalman-state propagation of a fitted SARIMA; filter update excluded"})
    df = pd.DataFrame(rows).groupby("model", as_index=False, sort=False).first()
    df["timed_runs_b1"] = cfg.latency_runs
    df["timed_runs_b256"] = cfg.latency_runs_batch256
    df["warmup_runs"] = cfg.latency_warmup
    U.atomic_to_csv(df, out)
    U.mark_done("latency")
    return df
