"""XGBoost + text features, seasonal ARIMA (state-space, multi-origin) and Prophet."""
import itertools
import os
import time
import warnings

import numpy as np
import pandas as pd

from . import utils as U

# ------------------------------------------------------------------ XGBoost
LAGS = list(range(1, 25)) + [36, 48, 72, 96, 120, 144, 168]


def xgb_features(data, origins, ctx_pca, ctx_variant="matched"):
    o = np.asarray(origins)
    X = [data.load_s[o[:, None] - np.array(LAGS)[None, :] + 1]]
    X.append(data.temp_z[o[:, None] + np.arange(-23, 1)[None, :]])
    X.append(data.temp_z[o[:, None] + np.arange(1, 25)[None, :]])
    d = data.day_of_hour[o]
    ts = data.ts[o + 1]
    X.append(np.stack([ts.hour, ts.dayofweek, ts.month, data.tone_for(ctx_variant)[d],
                       np.log1p(data.n_rec_lag[d])], 1))
    X.append(ctx_pca[d])
    return np.concatenate(X, 1).astype(np.float32)


def ctx_pca(cfg, data, n=16):
    from sklearn.decomposition import PCA
    c = data.ctx("matched", cfg.top_k)
    tr_days = np.unique(data.day_of_hour[data.origins_train])
    p = PCA(n_components=n, random_state=0).fit(c[tr_days])
    return p.transform(c).astype(np.float32)


def xgb_fit(params, Xtr, ytr, Xva, yva, seed):
    import xgboost as xgb
    import torch
    m = xgb.XGBRegressor(n_estimators=params["n_estimators"], max_depth=params["max_depth"],
                         learning_rate=params["eta"], subsample=0.8, colsample_bytree=0.8,
                         tree_method="hist", device="cuda" if torch.cuda.is_available() else "cpu",
                         random_state=seed, early_stopping_rounds=50, eval_metric="mae",
                         multi_strategy="one_output_per_tree")
    m.fit(Xtr, ytr, eval_set=[(Xva, yva)], verbose=False)
    return m


def run_xgb(cfg, data, seeds):
    import optuna
    from . import tune as TU
    feats = cfg.path("cache", "xgb_features.npz")

    def _feats():
        P = ctx_pca(cfg, data)
        np.savez(feats + ".tmp.npz",
                 Xtr=xgb_features(data, data.origins_train, P), Xva=xgb_features(data, data.origins_val, P),
                 Xte=xgb_features(data, data.origins_test, P), P=P)
        os.replace(feats + ".tmp.npz", feats)

    U.stage("xgb_features", feats, _feats)
    z = np.load(feats)
    Xtr, Xva, Xte = z["Xtr"], z["Xva"], z["Xte"]
    ytr = data.load_s[data.origins_train[:, None] + np.arange(1, 25)]
    yva_mw = data.y_mw(data.origins_val)
    yva = data.to_scaled(yva_mw)

    def objective(trial):
        p = {"max_depth": trial.suggest_int("max_depth", 3, 10),
             "n_estimators": trial.suggest_int("n_estimators", 100, 1000),
             "eta": trial.suggest_float("eta", 0.01, 0.3, log=True)}
        m = xgb_fit(p, Xtr, ytr, Xva, yva, cfg.single_run_seed)
        pr = data.to_mw(m.predict(Xva))
        return float((np.abs(pr - yva_mw) / yva_mw).mean() * 100)

    best = TU.tune(cfg, data, "xgb_text", objective_override=objective)
    out = {}
    for s in seeds:
        key = f"final:xgb_text:seed{s}"
        p = cfg.path("preds", "xgb_text", f"seed{s}_matched.npy")
        if U.is_done(key) and os.path.exists(p):
            U.log(f"[skip] XGBoost seed {s}")
            out[s] = p
            continue
        t0 = time.time()
        m = xgb_fit(best, Xtr, ytr, Xva, yva, s)
        U.atomic_save_npy(p, data.to_mw(m.predict(Xte)).astype(np.float32))
        m.save_model(cfg.path("preds", "xgb_text", f"seed{s}_model.json"))
        U.mark_done(key, {"seconds": round(time.time() - t0, 1), "best_iteration": int(m.best_iteration)})
        out[s] = p
    return best


# --------------------------------------------------------------------- ARIMA
def _exog(data, idx):
    t = data.temp_c[idx]
    return np.stack([t, np.abs(t - 18.0)], 1)


def arima_order_search(cfg, data, n_fit=2000):
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    n_tr = int(data.n_train_hours)
    idx = np.arange(n_tr - n_fit, n_tr)
    y = data.load_s[idx].astype(float)
    X = _exog(data, idx)
    rows = []
    for (p, q), seas in itertools.product(itertools.product([1, 2], [0, 1, 2]), [(1, 0, 1, 24), (0, 1, 1, 24)]):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            try:
                r = SARIMAX(y, exog=X, order=(p, 1, q), seasonal_order=seas).fit(disp=False, maxiter=200)
                rows.append({"order": (p, 1, q), "seasonal": seas, "aic": r.aic, "params": r.params})
                U.log(f"  ARIMA({p},1,{q}){seas[:3]}24 AIC {r.aic:.1f}")
            except Exception as e:  # noqa: BLE001
                U.warn(f"ARIMA({p},1,{q}){seas} failed: {e}")
    best = min(rows, key=lambda r: r["aic"])
    return best, rows


def arima_forecasts(data, best, origins, H=24):
    """Filter the whole series once with the fitted parameters, then forecast H steps from every origin
    with the state-space recursion y_{t+h|t} = d_{t+h} + Z T^h a_{t|t}."""
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    n = len(data.load_s)
    X = _exog(data, np.arange(n))
    mod = SARIMAX(data.load_s.astype(float), exog=X, order=best["order"], seasonal_order=best["seasonal"])
    res = mod.filter(best["params"])
    a = res.filtered_state                                   # k_states x n   (a_{t|t})
    Z = mod.ssm["design"][:, :, 0] if mod.ssm["design"].ndim == 3 else mod.ssm["design"]
    Tm = mod.ssm["transition"][:, :, 0] if mod.ssm["transition"].ndim == 3 else mod.ssm["transition"]
    c = mod.ssm["state_intercept"]
    c = c[:, 0] if c.ndim == 2 else c
    dvec = mod.ssm["obs_intercept"]                          # 1 x n
    o = np.asarray(origins)
    st = a[:, o]                                             # k x m
    out = np.zeros((len(o), H))
    for h in range(1, H + 1):
        st = Tm @ st + c[:, None]
        out[:, h - 1] = (Z @ st)[0] + dvec[0, o + h]
    return data.to_mw(out), res


def run_arima(cfg, data):
    p = cfg.path("preds", "arima", "seed0_matched.npy")
    info_p = cfg.path("preds", "arima", "info.json")

    def _run():
        best, rows = arima_order_search(cfg, data)
        pred, res = arima_forecasts(data, best, data.origins_test)
        U.atomic_save_npy(p, pred.astype(np.float32))
        ssm = res.model.ssm
        tm = ssm["transition"]
        zm = ssm["design"]
        np.savez(cfg.path("preds", "arima", "ssm.npz"), T=tm[:, :, 0] if tm.ndim == 3 else tm,
                 Z=zm[:, :, 0] if zm.ndim == 3 else zm, a=res.filtered_state[:, -1])
        U.atomic_write_json(info_p, {"order": best["order"], "seasonal_order": best["seasonal"],
                                     "aic": best["aic"], "n_params": int(len(best["params"])),
                                     "search": [{"order": r["order"], "seasonal": r["seasonal"], "aic": r["aic"]}
                                                for r in rows]})

    U.stage("arima", [p, info_p], _run)
    return p


# -------------------------------------------------------------------- Prophet
def run_prophet(cfg, data):
    p = cfg.path("preds", "prophet", "seed0_matched.npy")
    info_p = cfg.path("preds", "prophet", "info.json")

    def _run():
        from prophet import Prophet
        n_tr = int(data.n_train_hours)
        df = pd.DataFrame({"ds": data.ts, "y": data.load_mw, "temp": data.temp_c,
                           "tdev": np.abs(data.temp_c - 18.0)})
        m = Prophet(daily_seasonality=True, weekly_seasonality=True, yearly_seasonality=True)
        m.add_regressor("temp")
        m.add_regressor("tdev")
        m.fit(df.iloc[:n_tr])
        fc = m.predict(df[["ds", "temp", "tdev"]])["yhat"].values
        idx = data.origins_test[:, None] + np.arange(1, 25)[None, :]
        U.atomic_save_npy(p, fc[idx].astype(np.float32))
        U.atomic_write_json(info_p, {"seasonality": "daily + weekly + yearly", "regressors": ["temp", "|temp-18|"],
                                     "note": "fitted once on the training partition; forecasts do not depend on origin"})

    U.stage("prophet", [p, info_p], _run)
    return p
