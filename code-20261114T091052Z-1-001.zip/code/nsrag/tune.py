"""Optuna tuning with the same budget for every model, scored on validation MAPE only.

Storage is an append-only journal file on Drive. After a disconnect, trials left RUNNING are marked FAIL
and their parameters are queued again; because a trial's run folder is keyed by a hash of its parameters,
the requeued trial resumes from its last epoch checkpoint. Finished trials are never repeated.
"""
import hashlib
import json
import os
import shutil

import optuna

from . import train as T
from . import utils as U

SPACES = {
    "proposed": lambda t: {"lr": t.suggest_float("lr", 1e-5, 1e-3, log=True),
                           "lam": t.suggest_float("lam", 0.01, 1.0, log=True),
                           "w": t.suggest_categorical("w", [72, 168, 336])},
    "vanilla": lambda t: {"lr": t.suggest_float("lr", 1e-5, 1e-3, log=True),
                          "w": t.suggest_categorical("w", [72, 168, 336])},
    "informer": lambda t: {"d_model": t.suggest_categorical("d_model", [256, 512]),
                           "layers": t.suggest_categorical("layers", [2, 3]),
                           "lr": t.suggest_float("lr", 1e-5, 1e-3, log=True)},
    "informer_c": lambda t: {"d_model": t.suggest_categorical("d_model", [256, 512]),
                             "layers": t.suggest_categorical("layers", [2, 3]),
                             "lr": t.suggest_float("lr", 1e-5, 1e-3, log=True),
                             "lam": t.suggest_float("lam", 0.01, 1.0, log=True)},
    "patchtst": lambda t: {"patch": t.suggest_categorical("patch", [16, 24]),
                           "d_model": t.suggest_categorical("d_model", [64, 128]),
                           "layers": t.suggest_categorical("layers", [2, 3]),
                           "lr": t.suggest_float("lr", 1e-5, 1e-3, log=True)},
    "dlinear": lambda t: {"kernel": t.suggest_categorical("kernel", [13, 25]),
                          "lr": t.suggest_float("lr", 1e-4, 1e-2, log=True)},
    "timellm": lambda t: {"patch": t.suggest_categorical("patch", [16, 24]),
                          "prototypes": t.suggest_categorical("prototypes", [100, 1000]),
                          "lr": t.suggest_float("lr", 1e-5, 1e-3, log=True)},
}

SPACE_TEXT = {
    "proposed": "lr 1e-5 to 1e-3 (log); lambda 0.01 to 1 (log); w 72/168/336",
    "vanilla": "lr 1e-5 to 1e-3 (log); w 72/168/336",
    "informer": "d_model 256/512; encoder layers 2/3; lr 1e-5 to 1e-3 (log)",
    "informer_c": "as Informer + lambda 0.01 to 1 (log)",
    "patchtst": "patch 16/24; d_model 64/128; layers 2/3; lr 1e-5 to 1e-3 (log)",
    "dlinear": "kernel 13/25; lr 1e-4 to 1e-2 (log)",
    "timellm": "GPT-2 frozen; patch 16/24; prototypes 100/1000; lr 1e-5 to 1e-3 (log)",
    "xgb_text": "max_depth 3 to 10; n_estimators 100 to 1000; eta 0.01 to 0.3 (log)",
}


def _hash(params):
    return hashlib.md5(json.dumps(params, sort_keys=True).encode()).hexdigest()[:10]


def _storage(cfg, name):
    """Journal on Drive. Drive does not support symlinks, so the lock is an O_EXCL lock file; a lock left
    by a disconnected session is broken after 30 s."""
    from optuna.storages import JournalStorage
    try:
        from optuna.storages.journal import JournalFileBackend as Backend, JournalFileOpenLock as Lock
    except ImportError:  # older optuna
        from optuna.storages import JournalFileStorage as Backend, JournalFileOpenLock as Lock
    path = cfg.path("tuning", f"{name}.journal")
    try:
        lock = Lock(path, grace_period=30)
    except TypeError:
        lock = Lock(path)
    return JournalStorage(Backend(path, lock_obj=lock))


def _recover(study):
    """Fail trials left RUNNING by a disconnect and queue their parameters again."""
    for t in study.get_trials(deepcopy=False):
        if t.state == optuna.trial.TrialState.RUNNING:
            study._storage.set_trial_state_values(t._trial_id, optuna.trial.TrialState.FAIL)
            study.enqueue_trial(t.params, skip_if_exists=False)
            U.log(f"[resume] tuning trial {t.number} was interrupted; its parameters are queued again")


def tune(cfg, data, name, objective_override=None):
    """Run trials until cfg.tune_trials have finished (complete or pruned). Returns best params."""
    best_path = cfg.path("tuning", f"{name}_best.json")
    if U.is_done(f"tune:{name}") and os.path.exists(best_path):
        U.log(f"[skip] tuning {name}: best parameters cached")
        return U.read_json(best_path)["params"]
    study = optuna.create_study(study_name=name, storage=_storage(cfg, name), direction="minimize",
                                load_if_exists=True, sampler=optuna.samplers.TPESampler(seed=0),
                                pruner=optuna.pruners.MedianPruner(n_startup_trials=5, n_warmup_steps=3))
    _recover(study)

    def finished():
        return [t for t in study.get_trials(deepcopy=False)
                if t.state in (optuna.trial.TrialState.COMPLETE, optuna.trial.TrialState.PRUNED)]

    def objective(trial):
        if objective_override:
            return objective_override(trial)
        hp = SPACES[name](trial)
        run_dir = cfg.path("tuning", "runs", name, _hash(hp))
        try:
            s = T.train(cfg, data, name, hp, seed=cfg.single_run_seed, run_dir=run_dir,
                        max_epochs=cfg.tune_max_epochs, patience=cfg.tune_patience, trial=trial, keep_last=1,
                        train_origins=data.origins_train[::cfg.tune_train_stride])
        except optuna.TrialPruned:
            shutil.rmtree(os.path.join(run_dir, "ckpt"), ignore_errors=True)
            raise
        best = os.path.join(run_dir, "best.pt")
        if os.path.exists(best):
            os.remove(best)                      # trial weights are not needed after scoring
        return s["best_val_mape"]

    n_done = len(finished())
    if n_done:
        U.log(f"[resume] tuning {name}: {n_done}/{cfg.tune_trials} trials already finished")
    fails = 0
    while len(finished()) < cfg.tune_trials:
        before = len(finished())
        study.optimize(objective, n_trials=1, catch=(RuntimeError,))
        U.free_gpu()
        fails = 0 if len(finished()) > before else fails + 1
        if fails >= 5:
            raise RuntimeError(f"Tuning {name}: 5 trials in a row failed; see the log (often GPU out of memory: "
                               "lower batch_size or the largest window).")
        U.log(f"tuning {name}: {len(finished())}/{cfg.tune_trials} trials finished")
    best = study.best_trial
    out = {"params": best.params, "value_val_mape": best.value, "trial": best.number,
           "n_complete": sum(t.state == optuna.trial.TrialState.COMPLETE for t in study.trials),
           "n_pruned": sum(t.state == optuna.trial.TrialState.PRUNED for t in study.trials),
           "space": SPACE_TEXT.get(name, "")}
    U.atomic_write_json(best_path, out)
    df = study.trials_dataframe()
    U.atomic_to_csv(df, cfg.path("tuning", f"{name}_trials.csv"))
    U.mark_done(f"tune:{name}", {"best_val_mape": best.value})
    return best.params
