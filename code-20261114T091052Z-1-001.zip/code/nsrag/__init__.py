"""NS-RAG-LLM rerun pipeline (manuscript 1973902, round 2). Real data only: GEFCom2014 load + GDELT 1.0."""
__version__ = "2.0.0"
