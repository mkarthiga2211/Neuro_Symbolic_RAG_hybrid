"""Shared trainer: composite loss (Eq. 15-17), projection (Eq. 14), per-epoch atomic checkpoints with
optimizer, scheduler, AMP scaler, RNG and loader state, auto-resume, early stopping, and prediction."""
import glob
import json
import os
import shutil
import time

import numpy as np
import torch

from . import models as M
from . import utils as U
from .dataset import Batches

# How each trained variant uses the symbolic layer.
#   penalty: lambda * mean(max(0, y_raw - C)^2) on the raw forecast (Eq. 17)
#   mae_on_proj: forecasting MAE computed on the projected forecast (Eq. 16), else on the raw forecast
#   project: release the projected forecast at inference (Eq. 14)
VARIANTS = {
    "proposed":         dict(arch="proposed", penalty=True,  mae_on_proj=True,  project=True,  ctx="matched"),
    "proposed_sameday": dict(arch="proposed", penalty=True,  mae_on_proj=True,  project=True,  ctx="sameday"),
    "rag_only":         dict(arch="rag_only", penalty=False, mae_on_proj=False, project=False, ctx="matched"),
    "vanilla":          dict(arch="vanilla",  penalty=False, mae_on_proj=False, project=False, ctx="zero"),
    "pen_only":         dict(arch="pen_only", penalty=True,  mae_on_proj=False, project=False, ctx="zero"),
    "sym_only":         dict(arch="sym_only", penalty=True,  mae_on_proj=True,  project=True,  ctx="zero"),
    "informer":         dict(arch="informer", penalty=False, mae_on_proj=False, project=False, ctx="zero"),
    "informer_c":       dict(arch="informer", penalty=True,  mae_on_proj=True,  project=True,  ctx="zero"),
    "patchtst":         dict(arch="patchtst", penalty=False, mae_on_proj=False, project=False, ctx="zero"),
    "dlinear":          dict(arch="dlinear",  penalty=False, mae_on_proj=False, project=False, ctx="zero"),
    "timellm":          dict(arch="timellm",  penalty=False, mae_on_proj=False, project=False, ctx="zero"),
}


def project(y, C):
    """Euclidean projection onto [0, C] in MW, i.e. the box-constrained least-squares problem of Eq. 14.
    Its solution is the element-wise clamp; its gradient is the identity inside the box and zero outside,
    the same derivative a cvxpylayers QP layer returns."""
    return torch.clamp(y, min=C[0], max=C[1])


def _to_dev(np_batch, dev):
    return {k: torch.from_numpy(v).to(dev, non_blocking=True) for k, v in np_batch.items()}


def _bounds(data):
    return (float(data.to_scaled(0.0)), data.C)


def loss_fn(y_raw, y, spec, lam, bounds):
    pen = torch.relu(y_raw - bounds[1]).pow(2).mean()
    y_used = project(y_raw, bounds) if spec["mae_on_proj"] else y_raw
    mae = (y_used - y).abs().mean()
    total = mae + (lam * pen if spec["penalty"] else 0.0)
    return total, mae, pen


@torch.no_grad()
def predict_raw(model, data, origins, w, ctx_variant, K=None, seed=0, bs=512):
    """Raw (unprojected) forecasts in MW, shape (n_windows, 24)."""
    dev = next(model.parameters()).device
    model.eval()
    outs = []
    for i in range(0, len(origins), bs):
        b = _to_dev(data.inputs(origins[i:i + bs], w, ctx_variant, K, seed), dev)
        with torch.autocast(dev.type, dtype=torch.float16, enabled=dev.type == "cuda"):
            y = model(b)
        outs.append(y.float().cpu().numpy())
    return data.to_mw(np.concatenate(outs, 0))


def _ckpts(ckdir):
    return sorted(glob.glob(os.path.join(ckdir, "epoch_*.pt")),
                  key=lambda p: int(os.path.basename(p)[6:-3]))


def _trainable_state(model):
    """State dict without frozen weights (GPT-2 in Time-LLM is reloaded from the hub)."""
    frozen = {n for n, p in model.named_parameters() if not p.requires_grad}
    return {k: v for k, v in model.state_dict().items() if k not in frozen}


def train(cfg, data, name, hp, seed, run_dir, K=None, max_epochs=None, patience=None, trial=None,
          pretrained=True, train_origins=None, keep_last=None):
    """Train one model for one seed in run_dir. Resumes from the latest checkpoint; returns the summary.
    A finished run (done.json) is skipped."""
    spec = VARIANTS[name]
    done_path = os.path.join(run_dir, "done.json")
    if os.path.exists(done_path):
        U.log(f"[skip] {os.path.relpath(run_dir, cfg.project_dir)}: already trained")
        return U.read_json(done_path)
    os.makedirs(run_dir, exist_ok=True)
    ckdir = os.path.join(run_dir, "ckpt")
    os.makedirs(ckdir, exist_ok=True)
    max_epochs = max_epochs or cfg.max_epochs
    patience = patience or cfg.patience
    w = hp.get("w", cfg.window)
    lam = hp.get("lam", cfg.lam)
    lr = hp.get("lr", cfg.lr)
    K = K or hp.get("K", cfg.top_k)
    dev = U.device()
    U.set_seed(seed)
    model = M.build(spec["arch"], hp, cfg, pretrained=pretrained).to(dev)
    params = [p for p in model.parameters() if p.requires_grad]
    opt = torch.optim.AdamW(params, lr=lr, weight_decay=cfg.weight_decay)
    sched = torch.optim.lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5, patience=2)
    use_amp = cfg.amp and dev.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    tr_orig = data.origins_train if train_origins is None else train_origins
    loader = Batches(tr_orig, hp.get("batch_size", cfg.batch_size), True, seed)
    bounds = _bounds(data)
    state = {"epoch": 0, "best": float("inf"), "best_epoch": -1, "bad": 0, "history": []}

    cks = _ckpts(ckdir)
    if cks:
        ck = torch.load(cks[-1], map_location="cpu", weights_only=False)
        model.load_state_dict(ck["model"], strict=False)
        opt.load_state_dict(ck["optimizer"])
        sched.load_state_dict(ck["scheduler"])
        scaler.load_state_dict(ck["scaler"])
        loader.gen.set_state(ck["loader_gen"])
        U.set_rng_state(ck["rng"])
        state = ck["state"]
        U.log(f"[resume] {os.path.relpath(run_dir, cfg.project_dir)} from epoch {state['epoch']} "
              f"(best val MAE {state['best']:.3f} MW at epoch {state['best_epoch']})")
        if trial is not None:   # re-report history so the pruner sees the same curve
            for h in state["history"]:
                try:
                    trial.report(h["val_mape"], h["epoch"])
                except Exception:  # noqa: BLE001
                    pass

    val_o = data.origins_val
    y_val = data.y_mw(val_o)
    while state["epoch"] < max_epochs and state["bad"] < patience:
        ep = state["epoch"] + 1
        model.train()
        t0 = time.time()
        tot = mae_s = pen_s = 0.0
        nb = 0
        for o in loader:
            b = _to_dev(data.inputs(o, w, spec["ctx"], K, seed), dev)
            with torch.autocast(dev.type, dtype=torch.float16, enabled=use_amp):
                y_raw = model(b).float()
            total, mae, pen = loss_fn(y_raw, b["y"], spec, lam, bounds)
            opt.zero_grad(set_to_none=True)
            scaler.scale(total).backward()
            scaler.unscale_(opt)
            torch.nn.utils.clip_grad_norm_(params, 1.0)
            scaler.step(opt)
            scaler.update()
            tot += float(total.detach()) if torch.is_tensor(total) else float(total)
            mae_s += float(mae)
            pen_s += float(pen)
            nb += 1
        raw = predict_raw(model, data, val_o, w, spec["ctx"], K, seed)
        rel = np.clip(raw, 0, data.C_mw) if spec["project"] else raw
        val_mae = float(np.abs(rel - y_val).mean())
        val_mape = float((np.abs(rel - y_val) / np.abs(y_val)).mean() * 100)
        sched.step(val_mae)
        h = {"epoch": ep, "train_total": tot / nb, "train_mae": mae_s / nb, "train_penalty": pen_s / nb,
             "val_mae_mw": val_mae, "val_mape": val_mape, "lr": opt.param_groups[0]["lr"],
             "seconds": round(time.time() - t0, 1)}
        state["history"].append(h)
        state["epoch"] = ep
        improved = val_mae < state["best"] - 1e-6
        if improved:
            state["best"], state["best_epoch"], state["bad"] = val_mae, ep, 0
            U.atomic_torch_save({"model": _trainable_state(model), "epoch": ep, "hp": hp}, os.path.join(run_dir, "best.pt"))
        else:
            state["bad"] += 1
        U.atomic_torch_save({"model": _trainable_state(model), "optimizer": opt.state_dict(),
                             "scheduler": sched.state_dict(), "scaler": scaler.state_dict(),
                             "loader_gen": loader.gen.get_state(), "rng": U.rng_state(), "state": state},
                            os.path.join(ckdir, f"epoch_{ep}.pt"))
        for old in _ckpts(ckdir)[:-(keep_last or cfg.keep_last_ckpts)]:
            os.remove(old)
        U.atomic_to_csv(__import__("pandas").DataFrame(state["history"]), os.path.join(run_dir, "history.csv"))
        U.log(f"  epoch {ep}: loss {h['train_total']:.4f} (pen {h['train_penalty']:.5f}) "
              f"val MAE {val_mae:.2f} MW, MAPE {val_mape:.2f}% {'*' if improved else ''} [{h['seconds']} s]")
        if trial is not None:
            import optuna
            trial.report(val_mape, ep)
            if trial.should_prune():
                raise optuna.TrialPruned()
    if state["best_epoch"] < 0:
        raise RuntimeError(f"{name} seed {seed}: validation error never improved (NaN or divergence); "
                           "check the log, lower the learning rate, and delete the run folder to retry")
    best_hist = [h for h in state["history"] if h["epoch"] == state["best_epoch"]][0]
    summary = {"name": name, "seed": seed, "hp": hp, "K": K, "epochs_run": state["epoch"],
               "best_epoch": state["best_epoch"], "best_val_mae_mw": state["best"],
               "best_val_mape": best_hist["val_mape"], "n_params": M.n_params(model),
               "n_trainable": M.n_params(model, True)}
    U.atomic_write_json(done_path, summary)
    shutil.rmtree(ckdir, ignore_errors=True)     # epoch checkpoints are not needed once the run is done
    return summary


def load_best(cfg, data, name, hp, run_dir, pretrained=True):
    spec = VARIANTS[name]
    model = M.build(spec["arch"], hp, cfg, pretrained=pretrained).to(U.device())
    ck = torch.load(os.path.join(run_dir, "best.pt"), map_location="cpu", weights_only=False)
    model.load_state_dict(ck["model"], strict=False)
    model.eval()
    return model
