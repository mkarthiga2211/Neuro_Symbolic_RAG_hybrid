"""GEFCom2014 load track: acquire, parse and clean the real hourly load and temperature.

There is no synthetic fallback. If the data cannot be found the run stops with instructions.
"""
import glob
import os
import shutil
import subprocess
import zipfile

import numpy as np
import pandas as pd

from . import utils as U


def _download(url, dest):
    import requests
    U.log(f"Downloading {url}")
    with requests.get(url, stream=True, timeout=120, allow_redirects=True) as r:
        r.raise_for_status()
        tmp = dest + ".part"
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(1 << 20):
                f.write(chunk)
    os.replace(tmp, dest)


def _extract_nested(zpath, out_dir):
    """Extract a zip and every zip inside it."""
    with zipfile.ZipFile(zpath) as z:
        z.extractall(out_dir)
    for _ in range(4):
        inner = [p for p in glob.glob(os.path.join(out_dir, "**", "*.zip"), recursive=True)
                 if not os.path.exists(p + ".extracted")]
        if not inner:
            break
        for p in inner:
            try:
                with zipfile.ZipFile(p) as z:
                    z.extractall(os.path.splitext(p)[0])
                open(p + ".extracted", "w").close()
            except zipfile.BadZipFile:
                open(p + ".extracted", "w").close()


def acquire(cfg):
    """Make sure the GEFCom2014 files are extracted under data/raw/gefcom. Returns that folder."""
    raw = cfg.path("data", "raw")
    out = os.path.join(raw, "gefcom")
    if glob.glob(os.path.join(out, "**", "L*-train.csv"), recursive=True) or \
       glob.glob(os.path.join(out, "**", "*.csv"), recursive=True):
        return out
    os.makedirs(out, exist_ok=True)
    zpath = os.path.join(raw, cfg.gefcom_zip_name)
    if not os.path.exists(zpath):
        # 1) Kaggle mirror, if kaggle.json was copied from Drive
        if os.path.exists(os.path.expanduser("~/.kaggle/kaggle.json")):
            try:
                kdir = os.path.join(cfg.local_tmp, "kaggle_gefcom")
                os.makedirs(kdir, exist_ok=True)
                subprocess.run(["kaggle", "datasets", "download", "-d", cfg.kaggle_dataset, "-p", kdir],
                               check=True)
                zips = glob.glob(os.path.join(kdir, "*.zip"))
                if zips:
                    shutil.copy(zips[0], zpath)
            except Exception as e:  # noqa: BLE001
                U.warn(f"Kaggle download failed: {e}")
        # 2) public download links
        for url in cfg.gefcom_urls:
            if os.path.exists(zpath):
                break
            try:
                _download(url, zpath)
                zipfile.ZipFile(zpath).close()
            except Exception as e:  # noqa: BLE001
                U.warn(f"Download failed from {url}: {e}")
                if os.path.exists(zpath):
                    os.remove(zpath)
    if not os.path.exists(zpath):
        raise FileNotFoundError(
            "GEFCom2014 data not found and could not be downloaded.\n"
            f"Put GEFCom2014.zip (from Tao Hong's GEFCom2014 page or the Kaggle mirror {cfg.kaggle_dataset}) in\n"
            f"  {raw}\nor put kaggle.json in {cfg.path('credentials')} and run again.")
    U.log("Extracting GEFCom2014 (nested zips)")
    _extract_nested(zpath, out)
    return out


# ------------------------------------------------------------------ parsing
def _unpadded_dates(date_s):
    """Dates written as M D YYYY without zero padding (e.g. '112012' = 1 Jan 2012; '1112012' is 11 Jan or
    1 Nov). Ambiguous strings are resolved from the hourly order of the file: each date must equal the
    previous date or the day after it. The start is chosen as the reading with the fewest breaks."""
    import datetime as _dt
    run = (date_s != date_s.shift()).cumsum()            # consecutive rows with the same date string
    uniq = date_s.groupby(run).first().tolist()

    def cands(d):
        d = str(d)
        y, md = int(d[-4:]), d[:-4]
        out = []
        for k in range(1, len(md)):
            try:
                out.append(_dt.date(y, int(md[:k]), int(md[k:])))
            except ValueError:
                pass
        return out

    C = [cands(u) for u in uniq]

    def walk(first):
        res, prev, breaks = [], first, 0
        for i, cs in enumerate(C):
            if i == 0:
                pick = first
            elif not cs:
                res.append(None)
                continue
            else:
                ok = [c for c in cs if 0 <= (c - prev).days <= 1]
                if not ok:
                    breaks += 1
                pick = (ok or sorted(cs, key=lambda c: abs((c - prev).days)))[0]
            res.append(pick)
            prev = pick
        return res, breaks

    if not C or not C[0]:
        return pd.Series(pd.NaT, index=date_s.index)
    best = min((walk(f) for f in C[0]), key=lambda r: r[1])[0]
    vals = pd.Series([pd.Timestamp(d) if d is not None else pd.NaT for d in best], index=range(1, len(best) + 1))
    return pd.to_datetime(run.map(vals))


def _parse_timestamp(series):
    """GEFCom2014 load files use 'MMDDYYYY H:MM' (hour ending 1..24, sometimes without zero padding).
    Also accepts M/D/YYYY H:MM and YYYY-MM-DD H:MM."""
    s = series.astype(str).str.strip()
    parts = s.str.split(r"\s+", n=1, expand=True)
    date_s = parts[0]
    time_s = parts[1].fillna("0:00") if parts.shape[1] > 1 else pd.Series("0:00", index=s.index)
    hour = time_s.str.split(":", n=1).str[0].astype(int)
    if date_s.str.contains("/").any():
        date = pd.to_datetime(date_s, format="%m/%d/%Y", errors="coerce")
    elif date_s.str.contains("-").any():
        date = pd.to_datetime(date_s, format="%Y-%m-%d", errors="coerce")
    elif (date_s.str.len() == 8).all() and (date_s.str[:2].astype(int) <= 12).all():
        date = pd.to_datetime(date_s, format="%m%d%Y", errors="coerce")
    else:
        date = _unpadded_dates(date_s)
    if date.isna().any():
        bad = s[date.isna()].head(3).tolist()
        raise ValueError(f"Unparsed GEFCom timestamps, e.g. {bad}")
    hour_ending = (hour.max() == 24) or (hour.min() == 1)
    ts = date + pd.to_timedelta(hour - (1 if hour_ending else 0), unit="h")   # hour-beginning
    return ts, bool(hour_ending)


def parse(cfg, folder):
    """Read every GEFCom2014 load-track CSV and merge them into one hourly table."""
    files = sorted(glob.glob(os.path.join(folder, "**", "*.csv"), recursive=True))
    load_track = [f for f in files if "load" in os.path.relpath(f, folder).lower().split(os.sep)[:-1]
                  or "-l" in os.path.relpath(f, folder).lower()]
    if load_track:
        files = load_track                     # ignore the price, wind and solar tracks in the same zip
    frames, used, skipped = [], [], []
    hour_ending_flag = None
    for f in files:
        try:
            head = pd.read_csv(f, nrows=2)
        except Exception:  # noqa: BLE001
            continue
        cols = {c.upper(): c for c in head.columns}
        if "TIMESTAMP" not in cols:
            continue
        wcols = [c for c in head.columns if c.lower().startswith("w") and c[1:].isdigit()]
        if "LOAD" not in cols and not wcols:
            continue
        df = pd.read_csv(f)
        try:
            ts, he = _parse_timestamp(df[cols["TIMESTAMP"]])
        except ValueError as e:
            skipped.append(os.path.relpath(f, folder))
            U.warn(f"Skipped {os.path.relpath(f, folder)}: {e}")
            continue
        hour_ending_flag = he if hour_ending_flag is None else hour_ending_flag
        out = pd.DataFrame({"timestamp": ts})
        out["load"] = pd.to_numeric(df[cols["LOAD"]], errors="coerce") if "LOAD" in cols else np.nan
        if wcols:
            w = df[wcols].apply(pd.to_numeric, errors="coerce")
            out["temp_raw"] = w.mean(axis=1)
            out["n_stations"] = w.notna().sum(axis=1)
        else:
            out["temp_raw"] = np.nan
            out["n_stations"] = 0
        frames.append(out)
        used.append(os.path.relpath(f, folder))
    if not frames:
        raise FileNotFoundError(f"No GEFCom2014 load-track CSV files under {folder}")
    allf = pd.concat(frames, ignore_index=True)
    # combine: prefer non-null values for each timestamp
    agg = allf.groupby("timestamp").agg(load=("load", "first"), temp_raw=("temp_raw", "first"),
                                        n_stations=("n_stations", "max")).sort_index()
    # 'first' skips NaN within groups, so solution files fill load where train files lack it
    agg = agg[agg["load"].notna() & agg["temp_raw"].notna()]
    if len(agg) < 24 * 365:
        raise ValueError(f"Only {len(agg)} hours with both load and temperature; check the GEFCom files.")
    return agg, used, hour_ending_flag


def clean(cfg, agg):
    """Hourly reindex, linear interpolation of short gaps (Eq. 1), temperature in Celsius."""
    full = pd.date_range(agg.index.min(), agg.index.max(), freq="h")
    df = agg.reindex(full)
    df.index.name = "timestamp"
    gaps = df["load"].isna()
    # longest run of missing values
    run, longest = 0, 0
    for g in gaps.values:
        run = run + 1 if g else 0
        longest = max(longest, run)
    n_missing = int(gaps.sum())
    if longest > cfg.max_interp_gap_hours:
        U.warn(f"Longest load gap is {longest} h (> {cfg.max_interp_gap_hours}). "
               "Keeping the longest contiguous block instead of interpolating across it.")
        ok = (~gaps).astype(int)
        blk = (ok.diff().fillna(0) != 0).cumsum()
        sizes = ok.groupby(blk).sum()
        best = sizes.idxmax()
        df = df[blk == best]
        gaps = df["load"].isna()
        n_missing = int(gaps.sum())
    df["load"] = df["load"].interpolate("linear", limit_direction="both")
    df["temp_raw"] = df["temp_raw"].interpolate("linear", limit_direction="both")
    if cfg.gefcom_temp_unit.upper() == "F":
        df["temp_c"] = (df["temp_raw"] - 32.0) * 5.0 / 9.0
    else:
        df["temp_c"] = df["temp_raw"]
    facts = {
        "first_timestamp": str(df.index.min()),
        "last_timestamp": str(df.index.max()),
        "n_hours": int(len(df)),
        "n_interpolated_load_hours": n_missing,
        "longest_gap_hours": int(longest),
        "mean_load_mw": float(df["load"].mean()),
        "min_load_mw": float(df["load"].min()),
        "max_load_mw": float(df["load"].max()),
        "temp_unit_in_files": cfg.gefcom_temp_unit,
        "n_temperature_stations": int(agg["n_stations"].max()),
    }
    return df[["load", "temp_c"]], facts


def sanity_check(df):
    """Stop if the series looks synthetic or broken (the previous code silently used sine waves)."""
    r_abs = np.corrcoef(df["load"], np.abs(df["temp_c"] - 18.0))[0, 1]
    if df["load"].std() < 1e-6:
        raise ValueError("Load is constant: not real data.")
    if abs(r_abs) < 0.05:
        U.warn(f"|corr(load, |T-18|)| = {r_abs:.3f} is close to zero. Real GEFCom2014 load is strongly "
               "temperature driven. Check that the right files were read before going on.")
    U.log(f"Sanity check: corr(load, |T-18 C|) = {r_abs:.3f}")


def build(cfg):
    out_parquet = cfg.path("data", "processed", "load_hourly.parquet")
    out_facts = cfg.path("data", "processed", "load_facts.json")

    def _run():
        folder = acquire(cfg)
        agg, used, he = parse(cfg, folder)
        df, facts = clean(cfg, agg)
        sanity_check(df)
        facts["files_read"] = used[:50]
        facts["n_files_read"] = len(used)
        facts["timestamps_hour_ending_in_files"] = he
        U.atomic_to_parquet(df.reset_index(), out_parquet)
        U.atomic_write_json(out_facts, facts)
        U.log(f"GEFCom2014: {facts['first_timestamp']} to {facts['last_timestamp']}, "
              f"{facts['n_hours']} hours, mean {facts['mean_load_mw']:.1f} MW")

    U.stage("gefcom_load", [out_parquet, out_facts], _run)
    df = pd.read_parquet(out_parquet).set_index("timestamp")
    return df, U.read_json(out_facts)
