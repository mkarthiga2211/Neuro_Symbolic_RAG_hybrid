"""Subgroups (Block F), single-run and descriptive values (Block G) and Figures 2 to 16."""
import os

import numpy as np
import pandas as pd

from . import embed_retrieve as ER
from . import metrics as MT
from . import utils as U
from .experiments import released

FIG = None


def _plt():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams.update({"font.size": 12, "axes.titlesize": 13, "axes.labelsize": 12, "legend.fontsize": 11})
    return plt


def _save(cfg, fig, name):
    U.atomic_savefig(fig, cfg.path("results", "figures", name))
    _plt().close(fig)


def load_pred(cfg, model, seed, variant="matched"):
    p = cfg.path("preds", model, f"seed{seed}_{variant}.npy")
    return np.load(p) if os.path.exists(p) else None


def pred_variant(model):
    from .train import VARIANTS
    return VARIANTS[model]["ctx"] if model in VARIANTS else "matched"


def day_ahead_idx(data):
    """Indices of test windows issued at 23:00 (one non-overlapping 24 h forecast per day). With an origin
    stride that never lands on 23:00, the most frequent origin hour is used."""
    hrs = np.asarray(data.ts[data.origins_test].hour)
    h0 = 23 if (hrs == 23).any() else int(np.bincount(hrs).argmax())
    return np.where(hrs == h0)[0]


# ----------------------------------------------------------------- labels
def window_labels(cfg, data):
    o = data.origins_test
    issue = data.day_of_hour[o]
    target_day = data.day_of_hour[o + 1]
    days = data.days
    month = days.month.values[target_day]
    season = np.where(np.isin(month, [12, 1, 2]), "Winter", np.where(np.isin(month, [6, 7, 8]), "Summer", "Transition"))
    # daily max temperature
    dmax = pd.Series(data.temp_c).groupby(data.day_of_hour).max().reindex(range(len(days))).values
    n_tr = int(data.n_train_hours)
    tr_days = np.unique(data.day_of_hour[:n_tr])
    hw_thr = np.nanquantile(dmax[tr_days], cfg.heatwave_quantile)
    heat = dmax[target_day] >= hw_thr
    grid = data.n_grid_lag[issue] > 0
    act_thr = np.quantile(data.n_rec[tr_days], cfg.high_activity_quantile)
    high = data.n_rec_lag[issue] > act_thr
    event = np.where(heat, "Heatwave", np.where(grid, "Grid news", "Normal"))
    normal = ~heat & ~grid & ~high
    return pd.DataFrame({"season": season, "event": event, "heat": heat, "grid": grid, "high": high,
                         "normal": normal}), {"heatwave_threshold_c": float(hw_thr),
                                              "high_activity_threshold_records": float(act_thr)}


SUBGROUPS = {
    "Heatwave, Summer": lambda L: L["heat"] & (L["season"] == "Summer"),
    "Grid news, Winter": lambda L: L["grid"] & (L["season"] == "Winter"),
    "Normal, Transition": lambda L: L["normal"] & (L["season"] == "Transition"),
    "High GDELT Activity": lambda L: L["high"],
}


def block_f(cfg, data):
    y = data.y_mw(data.origins_test)
    L, thr = window_labels(cfg, data)
    rows = []
    for name, f in SUBGROUPS.items():
        m = f(L).values
        row = {"subgroup": name, "n_test_windows": int(m.sum())}
        for s in cfg.seeds:
            pv = load_pred(cfg, "vanilla", s, "zero")
            pp = load_pred(cfg, "proposed", s, "matched")
            if pv is None or pp is None or m.sum() == 0:
                row[f"seed{s}"] = np.nan
                continue
            pp = released(cfg, "proposed", pp, data.C_mw)
            row[f"seed{s}"] = MT.mape(y[m], pv[m]) - MT.mape(y[m], pp[m])
        rows.append(row)
    df = pd.DataFrame(rows)
    U.atomic_to_csv(df, cfg.path("results", "raw", "blockF_subgroups.csv"))
    U.atomic_write_json(cfg.path("results", "raw", "blockF_definitions.json"), {
        **thr, "season": "Winter = Dec-Feb, Summer = Jun-Aug, Transition = other months (target day)",
        "heatwave": f"target-day max temperature >= training {cfg.heatwave_quantile:.0%} quantile of daily max",
        "grid_news": f"lagged GDELT records include one of {list(cfg.grid_keywords)}",
        "high_activity": f"lagged filtered record count > training {cfg.high_activity_quantile:.0%} quantile",
        "normal": "not heatwave, not grid news, not high activity",
        "improvement": "MAPE(vanilla) - MAPE(proposed) in percentage points"})
    return df


# ------------------------------------------------------------- Block G + figures
def block_g(cfg, data, emb_path=None, records_path=None):
    plt = _plt()
    s0 = cfg.single_run_seed
    G = {"Seed used for single-run figures": s0}
    o = data.origins_test
    y = data.y_mw(o)
    C = data.C_mw

    # Figure 2: STL
    try:
        from statsmodels.tsa.seasonal import STL
        r = STL(pd.Series(data.load_mw, index=data.ts), period=24, robust=False).fit()
        fig, ax = plt.subplots(4, 1, figsize=(12, 9), sharex=True)
        for a, (lab, v) in zip(ax, [("Observed", data.load_mw), ("Trend", r.trend), ("Seasonal", r.seasonal),
                                    ("Residual", r.resid)]):
            a.plot(data.ts, v, lw=0.4)
            a.set_ylabel(lab + " (MW)")
        ax[0].set_title(f"STL decomposition of hourly load ({data.ts[0]:%Y-%m-%d} to {data.ts[-1]:%Y-%m-%d})")
        _save(cfg, fig, "fig02_stl.png")
        G["STL trend level, mean (MW)"] = float(np.nanmean(r.trend))
    except Exception as e:  # noqa: BLE001
        U.warn(f"Figure 2 skipped: {e}")

    # Figure 3: correlations
    t = data.temp_c
    r1 = float(np.corrcoef(data.load_mw, t)[0, 1])
    r2 = float(np.corrcoef(data.load_mw, np.abs(t - 18.0))[0, 1])
    G["Pearson r, hourly demand vs temperature"] = r1
    G["Pearson r, demand vs |temperature - 18 °C|"] = r2
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
    idx = np.random.default_rng(0).choice(len(t), min(20000, len(t)), replace=False)
    ax[0].scatter(t[idx], data.load_mw[idx], s=2, alpha=0.3)
    ax[0].set(xlabel="Temperature (C)", ylabel="Load (MW)", title=f"r = {r1:.2f}")
    ax[1].scatter(np.abs(t[idx] - 18), data.load_mw[idx], s=2, alpha=0.3)
    ax[1].set(xlabel="|Temperature - 18 C|", ylabel="Load (MW)", title=f"r = {r2:.2f}")
    _save(cfg, fig, "fig03_correlation.png")

    # Figure 4: PCA of embeddings coloured by tone
    if emb_path and records_path and os.path.exists(records_path):
        try:
            from sklearn.decomposition import PCA
            E = np.load(emb_path, mmap_mode="r")
            rec = pd.read_parquet(records_path, columns=["country", "tid", "tone"])
            rec = rec[rec["country"] == cfg.country]
            rec = rec.sample(min(20000, len(rec)), random_state=0)
            X = E[rec["tid"].values].astype(np.float32)
            P = PCA(2, random_state=0).fit_transform(X)
            fig, ax = plt.subplots(figsize=(7, 6))
            sc = ax.scatter(P[:, 0], P[:, 1], c=rec["tone"].values, s=3, cmap="coolwarm_r", alpha=0.6)
            fig.colorbar(sc, label="Average tone")
            ax.set(xlabel="PC1", ylabel="PC2", title="PCA of GDELT event embeddings")
            _save(cfg, fig, "fig04_pca_embeddings.png")
        except Exception as e:  # noqa: BLE001
            U.warn(f"Figure 4 skipped: {e}")

    # Figure 5: daily peak on normal vs high activity days
    peak = pd.Series(data.load_mw).groupby(data.day_of_hour).max()
    n_rec = pd.Series(data.n_rec).reindex(peak.index)
    tr_days = np.unique(data.day_of_hour[:int(data.n_train_hours)])
    thr = np.quantile(data.n_rec[tr_days], cfg.high_activity_quantile)
    has = n_rec > 0
    hi = (n_rec > thr) & has
    no = (~(n_rec > thr)) & has
    rng = np.random.default_rng(0)

    def boot(v):
        v = np.asarray(v)
        meds = [np.median(rng.choice(v, len(v))) for _ in range(cfg.bootstrap_reps)]
        return float(np.median(v)), float(np.percentile(meds, 2.5)), float(np.percentile(meds, 97.5))

    bh, bn = boot(peak[hi]), boot(peak[no])
    G["Figure 5: high-activity threshold (percentile of daily record count)"] = f"{cfg.high_activity_quantile * 100:.0f}th percentile of training daily record count = {thr:.0f} records"
    G["Figure 5: number of normal days / high-activity days"] = f"{int(no.sum())} / {int(hi.sum())}"
    G["Figure 5: median peak demand, high days (MW) and bootstrap 95% CI"] = f"{bh[0]:.1f} ({bh[1]:.1f} to {bh[2]:.1f})"
    G["Figure 5: median peak demand, normal days (MW) and bootstrap 95% CI"] = f"{bn[0]:.1f} ({bn[1]:.1f} to {bn[2]:.1f})"
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.violinplot([peak[no].values, peak[hi].values], showmedians=True)
    ax.set_xticks([1, 2], [f"Normal (n = {int(no.sum())})", f"High activity (n = {int(hi.sum())})"])
    for i, b in enumerate([bn, bh], 1):
        ax.errorbar(i, b[0], yerr=[[b[0] - b[1]], [b[2] - b[0]]], fmt="o", color="k", capsize=6)
    ax.set_ylabel("Daily peak load (MW)")
    ax.set_title("Daily peak load by GDELT activity (median with bootstrap 95% CI)")
    _save(cfg, fig, "fig05_violin_activity.png")

    # Figures 6, 7, 16 and correction sizes: vanilla raw vs projected
    pv = load_pred(cfg, "vanilla", s0, "zero")
    pp = load_pred(cfg, "proposed", s0, "matched")
    if pv is not None:
        viol_w = (pv > C).any(1)
        G["Vanilla LLM: windows with raw forecast above C (count)"] = int(viol_w.sum())
        corr = np.clip(pv - C, 0, None)
        ch = corr[corr > 0]
        G["Projection: mean / largest correction on those windows (MW)"] = (
            f"{ch.mean():.1f} / {ch.max():.1f} (over the {ch.size} corrected hours)" if ch.size else "no corrections")
        fig, ax = plt.subplots(figsize=(11, 4.5))
        ax.plot(pv.max(1), lw=0.5, color="tab:red", label="Vanilla LLM, window maximum (raw)")
        if pp is not None:
            ax.plot(np.clip(pp, 0, C).max(1), lw=0.5, color="tab:green", label="Proposed, window maximum (released)")
        ax.axhline(C, color="k", ls="--", label=f"C = {C:.0f} MW")
        ax.set(xlabel="Test window", ylabel="MW", title=f"Capacity compliance over {len(o)} test windows")
        ax.legend()
        _save(cfg, fig, "fig06_compliance.png")
        sel = np.where(viol_w)[0][:60] if viol_w.any() else np.argsort(-pv.max(1))[:60]
        for fname, zaxis in [("fig07_3d_projection.png", None), ("fig16_3d_temperature.png", "temp")]:
            fig = plt.figure(figsize=(9, 7))
            ax = fig.add_subplot(projection="3d")
            hh = np.tile(np.arange(1, 25), len(sel))
            ww = np.repeat(sel, 24)
            xs = hh if zaxis is None else data.temp_c[(o[sel][:, None] + np.arange(1, 25)).ravel()]
            raw = pv[sel].ravel()
            ax.scatter(ww, xs, raw, c="tab:red", s=6, label="Raw (vanilla)")
            ax.scatter(ww, xs, np.clip(raw, 0, C), c="tab:green", marker="D", s=6, label="Projected")
            X, Y = np.meshgrid([ww.min(), ww.max()], [xs.min(), xs.max()])
            ax.plot_surface(X, Y, np.full_like(X, C, dtype=float), alpha=0.2, color="gray")
            ax.set(xlabel="Test window", ylabel="Horizon (h)" if zaxis is None else "Temperature (C)", zlabel="MW")
            ax.legend()
            _save(cfg, fig, fname)

    # Figure 8: peak week (day-ahead windows issued at 23:00)
    if pv is not None and pp is not None:
        da = day_ahead_idx(data)
        if len(da) >= 7:
            daily_mean = y[da].mean(1)
            wk = int(np.argmax(np.convolve(daily_mean, np.ones(7), "valid")))
            sel = da[wk:wk + 7]
            yt, yv, yp = y[sel].ravel(), pv[sel].ravel(), np.clip(pp[sel], 0, C).ravel()
            tt = data.ts[(o[sel][:, None] + np.arange(1, 25)).ravel()]
            under = y[sel].max(1) - pv[sel].max(1)
            drop_i = int(np.argmin(np.diff(y[sel].max(1)))) + 1
            G["Peak week (Figure 8): vanilla under-prediction range at peaks (MW); date of the sharp drop"] = (
                f"{under.min():.1f} to {under.max():.1f}; {tt[drop_i * 24]:%d %B %Y}")
            fig, ax = plt.subplots(figsize=(12, 4.5))
            ax.plot(tt, yt, "k", lw=1.5, label="Ground truth")
            ax.plot(tt, yv, "tab:red", lw=1, label="Vanilla LLM")
            ax.plot(tt, yp, "tab:green", lw=1, label="Proposed NS-RAG")
            ax.set(ylabel="Load (MW)", title=f"Highest-load test week from {tt[0]:%d %b %Y}")
            ax.legend()
            _save(cfg, fig, "fig08_peak_week.png")

    # Figure 9: heatmap single run
    L, _ = window_labels(cfg, data)
    if pv is not None and pp is not None:
        ppr = np.clip(pp, 0, C)
        seasons, events = ["Winter", "Transition", "Summer"], ["Normal", "Heatwave", "Grid news"]
        H = np.full((len(events), len(seasons)), np.nan)
        N = np.zeros_like(H, dtype=int)
        for i, ev in enumerate(events):
            for j, se in enumerate(seasons):
                m = ((L["event"] == ev) & (L["season"] == se)).values
                N[i, j] = m.sum()
                if m.sum() >= 20:
                    H[i, j] = MT.mape(y[m], pv[m]) - MT.mape(y[m], ppr[m])
        fig, ax = plt.subplots(figsize=(7, 4.5))
        im = ax.imshow(H, cmap="YlGn")
        ax.set_xticks(range(3), seasons)
        ax.set_yticks(range(3), events)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, "n<20" if np.isnan(H[i, j]) else f"{H[i, j]:.2f}\n(n={N[i, j]})", ha="center",
                        va="center", fontsize=10)
        fig.colorbar(im, label="MAPE improvement (points)")
        ax.set_title(f"Improvement over the vanilla LLM (seed {s0})")
        _save(cfg, fig, "fig09_heatmap.png")
        def rng_txt(row):
            v = H[row][~np.isnan(H[row])]
            return f"{v.min():.2f} to {v.max():.2f}" if v.size else "n < 20 in all cells"
        G["Figure 9 heatmap: Normal improvement range across seasons (points)"] = rng_txt(0)
        G["Figure 9 heatmap: Grid Maintenance range (points)"] = rng_txt(2)
        G["Figure 9 heatmap: Heatwave summer (points)"] = "n < 20" if np.isnan(H[1, 2]) else f"{H[1, 2]:.2f}"
        pd.DataFrame(H, index=events, columns=seasons).to_csv(cfg.path("results", "raw", "fig09_heatmap_values.csv"))

    # Figure 12: training curve
    hist_p = cfg.path("checkpoints", "proposed", f"seed{s0}", "history.csv")
    if os.path.exists(hist_p):
        h = pd.read_csv(hist_p)
        G["Training (Figure 12): epochs run; total loss first / last; penalty first / last"] = (
            f"{len(h)}; {h.train_total.iloc[0]:.4f} / {h.train_total.iloc[-1]:.4f}; "
            f"{h.train_penalty.iloc[0]:.5f} / {h.train_penalty.iloc[-1]:.5f}")
        fig, ax = plt.subplots(figsize=(7, 4.5))
        ax.plot(h.epoch, h.train_total, "o-", label="Total loss")
        ax.plot(h.epoch, h.train_penalty, "s-", label="Symbolic penalty")
        ax.set(xlabel="Epoch", ylabel="Loss (scaled units)", title="Training convergence (proposed, seed %d)" % s0)
        ax.legend()
        _save(cfg, fig, "fig12_training.png")

    # Figure 13: tier confusion; Figure 14: extreme events
    if pp is not None:
        ppr = np.clip(pp, 0, C)
        ytr = data.load_mw[:int(data.n_train_hours)]
        q1, q2 = np.quantile(ytr, cfg.tier_quantiles)
        tier = lambda v: np.digitize(v, [q1, q2])
        from sklearn.metrics import average_precision_score, confusion_matrix, roc_auc_score, roc_curve, \
            precision_recall_curve
        cm = confusion_matrix(tier(y.ravel()), tier(ppr.ravel()), labels=[0, 1, 2], normalize="true") * 100
        G["Confusion matrix (Figure 13): Low correct %, Normal correct %, Peak correct %, Peak→Normal %"] = (
            f"{cm[0, 0]:.1f}, {cm[1, 1]:.1f}, {cm[2, 2]:.1f}, {cm[2, 1]:.1f} (tiers: training quantiles "
            f"{cfg.tier_quantiles[0]:.2f} / {cfg.tier_quantiles[1]:.2f} = {q1:.0f} / {q2:.0f} MW)")
        fig, ax = plt.subplots(figsize=(5.5, 4.5))
        im = ax.imshow(cm, cmap="Blues", vmin=0, vmax=100)
        labs = ["Low", "Normal", "Peak"]
        ax.set_xticks(range(3), labs)
        ax.set_yticks(range(3), labs)
        for i in range(3):
            for j in range(3):
                ax.text(j, i, f"{cm[i, j]:.0f}%", ha="center", va="center")
        ax.set(xlabel="Predicted tier", ylabel="Actual tier", title="Demand tier confusion (normalised)")
        _save(cfg, fig, "fig13_confusion.png")
        thr = np.quantile(ytr, cfg.extreme_quantile)
        lab = (y.ravel() >= thr).astype(int)
        if 0 < lab.sum() < lab.size:
            auc = roc_auc_score(lab, ppr.ravel())
            ap = average_precision_score(lab, ppr.ravel())
            G["Extreme events (Figure 14): ROC AUC; average precision"] = (
                f"{auc:.3f}; {ap:.3f} (threshold = training {cfg.extreme_quantile:.0%} quantile = {thr:.0f} MW; "
                f"{lab.mean() * 100:.1f}% of test hours)")
            fpr, tpr, _ = roc_curve(lab, ppr.ravel())
            pr, rc, _ = precision_recall_curve(lab, ppr.ravel())
            fig, ax = plt.subplots(1, 2, figsize=(11, 4.5))
            ax[0].plot(fpr, tpr)
            ax[0].plot([0, 1], [0, 1], "k--")
            ax[0].set(xlabel="False positive rate", ylabel="True positive rate", title=f"ROC (AUC = {auc:.2f})")
            ax[1].plot(rc, pr)
            ax[1].set(xlabel="Recall", ylabel="Precision", title=f"Precision-recall (AP = {ap:.2f})")
            _save(cfg, fig, "fig14_extreme_events.png")
        else:
            G["Extreme events (Figure 14): ROC AUC; average precision"] = "no extreme hours in the test set"

    # Top-K (Table 2)
    tk = []
    for K in cfg.retrieval_ks:
        name = "proposed" if K == cfg.top_k else f"proposed_K{K}"
        p = load_pred(cfg, name, s0, "matched")
        tk.append(f"{MT.mape(y, np.clip(p, 0, C)):.2f}" if p is not None else "not run")
    G["Top-K (Table 2): MAPE for K = " + ", ".join(map(str, cfg.retrieval_ks))] = ", ".join(tk)

    U.atomic_write_json(cfg.path("results", "raw", "blockG_single_run.json"), G)
    return G


def figure15(cfg, ablation_df):
    plt = _plt()
    order = ["Base LLM (vanilla)", "Symbolic-only", "RAG-only", "Proposed (full)"]
    d = ablation_df.set_index("variant")
    vals = [d.loc[v, [f"seed{s}" for s in cfg.seeds]].astype(float).values for v in order if v in d.index]
    labs = [v for v in order if v in d.index]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.bar(labs, [np.nanmean(v) for v in vals], yerr=[np.nanstd(v, ddof=1) for v in vals], capsize=6,
           color=["#999999", "#6baed6", "#74c476", "#31a354"][:len(labs)])
    ax.set(ylabel="MAPE (%)", title="Ablation: five-seed mean MAPE (± SD)")
    _save(cfg, fig, "fig15_ablation.png")


# ---------------------------------------------------------------- SHAP + UMAP
def shap_and_umap(cfg, data, emb_path, retr_paths, text_ids_path):
    """Figure 10 (word-level SHAP on the retrieved snippets) and Figure 11 (UMAP of the corpus)."""
    import torch
    from . import train as T
    from . import experiments as X
    plt = _plt()
    out = {}
    s0 = cfg.single_run_seed
    run_dir = cfg.path("checkpoints", "proposed", f"seed{s0}")
    if not os.path.exists(os.path.join(run_dir, "best.pt")):
        U.warn("SHAP skipped: proposed seed-0 weights not kept")
        return out
    hp = X.best_hp(cfg, data, "proposed")
    model = T.load_best(cfg, data, "proposed", hp, run_dir)
    w, K = hp.get("w", cfg.window), hp.get("K", cfg.top_k)
    texts = pd.read_parquet(text_ids_path)["text"].values
    z = np.load(retr_paths["matched"])
    o = data.origins_test
    y = data.y_mw(o)
    i = int(np.argmax(y.mean(1)))                                    # representative high-demand window
    d = data.day_of_hour[o[i]]
    ids, sims = z["ids"][d, :K], z["sims"][d, :K]
    wts = np.exp(sims / cfg.retrieval_temperature - (sims / cfg.retrieval_temperature).max())
    wts /= wts.sum()
    snippets = [texts[j] for j in ids]
    words = [(k, wd) for k, sn in enumerate(snippets) for wd in sn.split()]
    base = data.inputs(o[i:i + 1], w, "matched", K, s0)
    dev = U.device()

    def f(M):
        outs = []
        for row in np.atleast_2d(M):
            sn = [" ".join(wd for (k2, wd), keep in zip(words, row) if k2 == k and keep > 0.5) for k in range(K)]
            e = ER.embed_texts(cfg, [s if s else "." for s in sn]).astype(np.float32)
            c = (wts[:, None] * e).sum(0, keepdims=True)
            b = {k: torch.from_numpy(v).to(dev) for k, v in base.items()}
            b["ctx"] = torch.from_numpy(c).to(dev)
            with torch.no_grad():
                outs.append(float(data.to_mw(model(b).float().cpu().numpy()).mean()))
        return np.array(outs)

    if cfg.run_shap:
        try:
            import shap
            F_ = len(words)
            ex = shap.PermutationExplainer(f, shap.maskers.Independent(np.zeros((1, F_))), max_evals=max(2 * F_ + 1, 300))
            sv = ex(np.ones((1, F_))).values[0]
            toks = pd.DataFrame({"token": [wd.strip(".,:;()'\"").lower() for _, wd in words], "shap_mw": sv})
            toks = toks[toks.token.str.len() > 0]
            toks = toks.groupby("token", as_index=False)["shap_mw"].sum().sort_values("shap_mw")
            U.atomic_to_csv(toks, cfg.path("results", "raw", "fig10_shap_tokens.csv"))
            up = toks[toks.shap_mw > 0].tail(4)["token"].tolist()[::-1]
            dn = toks[toks.shap_mw < 0].head(4)["token"].tolist()
            out["SHAP (Figure 10): tokens pushing forecast up / down"] = f"{', '.join(up)} / {', '.join(dn)}"
            show = pd.concat([toks.head(8), toks.tail(8)]).drop_duplicates()
            fig, ax = plt.subplots(figsize=(7, 6))
            ax.barh(show.token, show.shap_mw, color=np.where(show.shap_mw > 0, "tab:red", "tab:blue"))
            ax.set(xlabel="SHAP value (MW, mean 24-h forecast)",
                   title=f"Token attribution, window issued {data.ts[o[i]]:%Y-%m-%d %H:%M}")
            _save(cfg, fig, "fig10_shap.png")
            U.atomic_write_json(cfg.path("results", "raw", "fig10_retrieved_snippets.json"),
                                {"window_origin": str(data.ts[o[i]]), "snippets": snippets,
                                 "weights": wts.tolist(), "similarities": sims.tolist()})
        except Exception as e:  # noqa: BLE001
            U.warn(f"SHAP skipped: {e}")
            out["SHAP (Figure 10): tokens pushing forecast up / down"] = "not run"

    if cfg.run_umap:
        try:
            E = np.load(emb_path, mmap_mode="r")
            rng = np.random.default_rng(0)
            days_valid = np.where(z["valid"])[0]
            pick = rng.choice(days_valid, min(3000, len(days_valid)), replace=False)
            next_mean = pd.Series(data.load_mw).groupby(data.day_of_hour).mean().reindex(range(len(data.days))).values
            Q = np.stack([E[z["ids"][dd, :K]].astype(np.float32).mean(0) for dd in pick])
            pts = np.vstack([Q, E[ids].astype(np.float32), E[ids].astype(np.float32).mean(0, keepdims=True)])
            try:
                import umap
                P = umap.UMAP(n_neighbors=15, random_state=0).fit_transform(pts)
                meth = "UMAP"
            except ImportError:
                from sklearn.decomposition import PCA
                P = PCA(2).fit_transform(pts)
                meth = "PCA (umap-learn not installed)"
            fig, ax = plt.subplots(figsize=(7.5, 6))
            sc = ax.scatter(P[:len(pick), 0], P[:len(pick), 1], c=next_mean[pick], s=5, cmap="viridis", alpha=0.6)
            ax.scatter(P[len(pick):-1, 0], P[len(pick):-1, 1], marker="D", s=60, c="orange", edgecolor="k",
                       label="Retrieved twins")
            ax.scatter(P[-1, 0], P[-1, 1], marker="*", s=250, c="red", edgecolor="k", label="Target context")
            fig.colorbar(sc, label="Mean daily load (MW)")
            ax.set_title(f"{meth} of daily context embeddings")
            ax.legend()
            _save(cfg, fig, "fig11_umap.png")
        except Exception as e:  # noqa: BLE001
            U.warn(f"Figure 11 skipped: {e}")
    return out
