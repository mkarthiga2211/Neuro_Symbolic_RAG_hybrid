"""Error metrics, violation rate, paired t-tests and the Diebold-Mariano test."""
import numpy as np
from scipy import stats


def mape(y, p, mask=None):
    e = np.abs(p - y) / np.abs(y)
    if mask is not None:
        e = e[mask]
    return float(e.mean() * 100) if e.size else float("nan")


def mae(y, p, mask=None):
    e = np.abs(p - y)
    if mask is not None:
        e = e[mask]
    return float(e.mean()) if e.size else float("nan")


def rmse(y, p):
    return float(np.sqrt(((p - y) ** 2).mean()))


def violation(p, C):
    """Percent of windows whose forecast exceeds C in at least one of the 24 hours."""
    return float((p > C + 1e-9).any(1).mean() * 100)


def all_metrics(y, p, C):
    return {"MAPE": mape(y, p), "MAE": mae(y, p), "RMSE": rmse(y, p), "Violation": violation(p, C)}


def paired_t(a, b):
    """Two-sided paired t-test on seed-level values; difference = b - a (baseline minus proposed)."""
    a, b = np.asarray(a, float), np.asarray(b, float)
    d = b - a
    n = len(d)
    t, p = stats.ttest_rel(b, a)
    se = d.std(ddof=1) / np.sqrt(n)
    h = stats.t.ppf(0.975, n - 1) * se
    return {"mean_diff": float(d.mean()), "ci_low": float(d.mean() - h), "ci_high": float(d.mean() + h),
            "t": float(t), "df": n - 1, "p": float(p)}


def diebold_mariano(e1, e2, lag=24):
    """DM test on absolute-error loss differentials d = |e2| - |e1| with a Newey-West variance (Bartlett)."""
    d = np.abs(np.asarray(e2)) - np.abs(np.asarray(e1))
    d = d[~np.isnan(d)]
    n = len(d)
    dm = d.mean()
    dc = d - dm
    gamma0 = (dc @ dc) / n
    s = gamma0
    for k in range(1, lag + 1):
        g = (dc[k:] @ dc[:-k]) / n
        s += 2 * (1 - k / (lag + 1)) * g
    stat = dm / np.sqrt(s / n)
    p = 2 * (1 - stats.norm.cdf(abs(stat)))
    return {"DM": float(stat), "p": float(p), "n": int(n)}
